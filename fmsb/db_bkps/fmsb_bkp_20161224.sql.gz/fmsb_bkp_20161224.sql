-- MySQL dump 10.13  Distrib 5.6.23, for Win64 (x86_64)
--
-- Host: localhost    Database: fmsb
-- ------------------------------------------------------
-- Server version	5.6.25-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aldryn_bootstrap3_boostrap3alertplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_boostrap3alertplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_boostrap3alertplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `context` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_799ba2bf_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_boostrap3alertplugin`
--

LOCK TABLES `aldryn_bootstrap3_boostrap3alertplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3alertplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3alertplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_boostrap3blockquoteplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_boostrap3blockquoteplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_boostrap3blockquoteplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `reverse` tinyint(1) NOT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_480dda7b_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_boostrap3blockquoteplugin`
--

LOCK TABLES `aldryn_bootstrap3_boostrap3blockquoteplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3blockquoteplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3blockquoteplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_boostrap3buttonplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_boostrap3buttonplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_boostrap3buttonplugin` (
  `link_url` varchar(200) NOT NULL,
  `link_anchor` varchar(128) NOT NULL,
  `link_mailto` varchar(254) DEFAULT NULL,
  `link_phone` varchar(40) DEFAULT NULL,
  `link_target` varchar(100) NOT NULL,
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `label` varchar(256) NOT NULL,
  `type` varchar(10) NOT NULL,
  `btn_context` varchar(255) NOT NULL,
  `btn_size` varchar(255) NOT NULL,
  `btn_block` tinyint(1) NOT NULL,
  `txt_context` varchar(255) NOT NULL,
  `icon_left` varchar(255) NOT NULL,
  `icon_right` varchar(255) NOT NULL,
  `classes` longtext NOT NULL,
  `responsive` longtext NOT NULL,
  `responsive_print` longtext NOT NULL,
  `link_file_id` int(11) DEFAULT NULL,
  `link_page_id` int(11) DEFAULT NULL,
  `link_attributes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `aldryn_bootstrap3_boostrap3buttonplugin_6e2e5dae` (`link_file_id`),
  KEY `aldryn_bootstrap3_boostrap3buttonplugin_5b76e141` (`link_page_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_3edc146a_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`),
  CONSTRAINT `aldryn_bootstrap3_boostra_link_file_id_16a82892_fk_filer_file_id` FOREIGN KEY (`link_file_id`) REFERENCES `filer_file` (`id`),
  CONSTRAINT `aldryn_bootstrap3_boostrap3b_link_page_id_4d19791_fk_cms_page_id` FOREIGN KEY (`link_page_id`) REFERENCES `cms_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_boostrap3buttonplugin`
--

LOCK TABLES `aldryn_bootstrap3_boostrap3buttonplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3buttonplugin` DISABLE KEYS */;
INSERT INTO `aldryn_bootstrap3_boostrap3buttonplugin` VALUES ('','','','','',127,' Saiba mais','btn','info','md',0,'','fa-info-circle','',' animation animated-item-3','','',NULL,6,'{}'),('','','','','',136,'Filie-se','btn','success','md',0,'','fa-check-square-o','',' animation animated-item-3','','',NULL,3,'{}'),('','','','','',145,' Saiba mais','btn','info','md',0,'','fa-info-circle','',' animation animated-item-3','','',NULL,6,'{}'),('','','','','',178,' Saiba mais','btn','info','md',0,'','fa-info-circle','',' animation animated-item-3','','',NULL,6,'{}'),('','','','','',187,'Filie-se','btn','success','md',0,'','fa-check-square-o','',' animation animated-item-3','','',NULL,3,'{}'),('','','','','',196,' Saiba mais','btn','info','md',0,'','fa-info-circle','',' animation animated-item-3','','',NULL,6,'{}');
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3buttonplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_boostrap3iconplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_boostrap3iconplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_boostrap3iconplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_4c4848ab_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_boostrap3iconplugin`
--

LOCK TABLES `aldryn_bootstrap3_boostrap3iconplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3iconplugin` DISABLE KEYS */;
INSERT INTO `aldryn_bootstrap3_boostrap3iconplugin` VALUES (146,'fa-book',''),(152,'fa-book',''),(155,'fa-user',''),(158,'fa-trophy',''),(161,'fa-group',''),(164,'fa-info-circle',''),(167,'fa-thumbs-up',''),(199,'fa-book',''),(203,'fa-user',''),(206,'fa-trophy',''),(209,'fa-group',''),(212,'fa-info-circle',''),(215,'fa-thumbs-up','');
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3iconplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_boostrap3imageplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_boostrap3imageplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_boostrap3imageplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `alt` longtext NOT NULL,
  `title` longtext NOT NULL,
  `aspect_ratio` varchar(10) NOT NULL,
  `thumbnail` tinyint(1) NOT NULL,
  `shape` varchar(64) NOT NULL,
  `classes` longtext NOT NULL,
  `img_responsive` tinyint(1) NOT NULL,
  `file_id` int(11) DEFAULT NULL,
  `override_height` int(11),
  `override_width` int(11),
  `use_original_image` tinyint(1) NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `aldryn_bootstrap3_boostrap3imageplugin_814552b9` (`file_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_567daa14_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`),
  CONSTRAINT `aldryn_bootstrap3_bo_file_id_3df3490a_fk_filer_image_file_ptr_id` FOREIGN KEY (`file_id`) REFERENCES `filer_image` (`file_ptr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_boostrap3imageplugin`
--

LOCK TABLES `aldryn_bootstrap3_boostrap3imageplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3imageplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3imageplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_boostrap3labelplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_boostrap3labelplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_boostrap3labelplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `label` varchar(256) NOT NULL,
  `context` varchar(255) NOT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_1c1d39b7_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_boostrap3labelplugin`
--

LOCK TABLES `aldryn_bootstrap3_boostrap3labelplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3labelplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3labelplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_boostrap3panelbodyplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_boostrap3panelbodyplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_boostrap3panelbodyplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3_b_cmsplugin_ptr_id_e8969d9_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_boostrap3panelbodyplugin`
--

LOCK TABLES `aldryn_bootstrap3_boostrap3panelbodyplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3panelbodyplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3panelbodyplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_boostrap3panelfooterplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_boostrap3panelfooterplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_boostrap3panelfooterplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_668c619a_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_boostrap3panelfooterplugin`
--

LOCK TABLES `aldryn_bootstrap3_boostrap3panelfooterplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3panelfooterplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3panelfooterplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_boostrap3panelheadingplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_boostrap3panelheadingplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_boostrap3panelheadingplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `title` longtext NOT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_22f8b468_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_boostrap3panelheadingplugin`
--

LOCK TABLES `aldryn_bootstrap3_boostrap3panelheadingplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3panelheadingplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3panelheadingplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_boostrap3panelplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_boostrap3panelplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_boostrap3panelplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `context` varchar(255) NOT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_44c14c4f_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_boostrap3panelplugin`
--

LOCK TABLES `aldryn_bootstrap3_boostrap3panelplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3panelplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3panelplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_boostrap3spacerplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_boostrap3spacerplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_boostrap3spacerplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `size` varchar(255) NOT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_24e44e1a_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_boostrap3spacerplugin`
--

LOCK TABLES `aldryn_bootstrap3_boostrap3spacerplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3spacerplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3spacerplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_boostrap3wellplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_boostrap3wellplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_boostrap3wellplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `size` varchar(255) NOT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_4519f230_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_boostrap3wellplugin`
--

LOCK TABLES `aldryn_bootstrap3_boostrap3wellplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3wellplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_boostrap3wellplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_bootstrap3accordionitemplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_bootstrap3accordionitemplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_bootstrap3accordionitemplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `title` longtext NOT NULL,
  `context` varchar(255) NOT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_32f2687d_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_bootstrap3accordionitemplugin`
--

LOCK TABLES `aldryn_bootstrap3_bootstrap3accordionitemplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3accordionitemplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3accordionitemplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_bootstrap3accordionplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_bootstrap3accordionplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_bootstrap3accordionplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `index` int(10) unsigned DEFAULT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_3e0564e6_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_bootstrap3accordionplugin`
--

LOCK TABLES `aldryn_bootstrap3_bootstrap3accordionplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3accordionplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3accordionplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_bootstrap3carouselplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_bootstrap3carouselplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_bootstrap3carouselplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `style` varchar(50) NOT NULL,
  `aspect_ratio` varchar(10) NOT NULL,
  `transition_effect` varchar(50) NOT NULL,
  `ride` tinyint(1) NOT NULL,
  `interval` int(11) NOT NULL,
  `wrap` tinyint(1) NOT NULL,
  `pause` tinyint(1) NOT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_5628dca5_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_bootstrap3carouselplugin`
--

LOCK TABLES `aldryn_bootstrap3_bootstrap3carouselplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3carouselplugin` DISABLE KEYS */;
INSERT INTO `aldryn_bootstrap3_bootstrap3carouselplugin` VALUES (118,'standard','21x9','slide',1,4000,1,1,'fmsb-carousel'),(169,'standard','21x9','slide',1,4000,1,1,'fmsb-carousel');
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3carouselplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_bootstrap3carouselslidefolderplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_bootstrap3carouselslidefolderplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_bootstrap3carouselslidefolderplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `classes` longtext NOT NULL,
  `folder_id` int(11) NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `aldryn_bootstrap3_bootstrap3carouselslidefolderplugin_a8a44dbb` (`folder_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_19625dd3_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`),
  CONSTRAINT `aldryn_bootstrap3_bootstra_folder_id_432a63ef_fk_filer_folder_id` FOREIGN KEY (`folder_id`) REFERENCES `filer_folder` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_bootstrap3carouselslidefolderplugin`
--

LOCK TABLES `aldryn_bootstrap3_bootstrap3carouselslidefolderplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3carouselslidefolderplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3carouselslidefolderplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_bootstrap3carouselslideplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_bootstrap3carouselslideplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_bootstrap3carouselslideplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `link_url` varchar(200) NOT NULL,
  `link_anchor` varchar(128) NOT NULL,
  `link_mailto` varchar(254) DEFAULT NULL,
  `link_phone` varchar(40) DEFAULT NULL,
  `link_target` varchar(100) NOT NULL,
  `link_text` varchar(200) NOT NULL,
  `content` longtext NOT NULL,
  `classes` longtext NOT NULL,
  `image_id` int(11) DEFAULT NULL,
  `link_file_id` int(11) DEFAULT NULL,
  `link_page_id` int(11) DEFAULT NULL,
  `link_attributes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `aldryn_bootstrap3_bootstrap3carouselslideplugin_f33175e6` (`image_id`),
  KEY `aldryn_bootstrap3_bootstrap3carouselslideplugin_6e2e5dae` (`link_file_id`),
  KEY `aldryn_bootstrap3_bootstrap3carouselslideplugin_5b76e141` (`link_page_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_1c7ef5b1_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`),
  CONSTRAINT `aldryn_bootstrap3_b_image_id_73adeea7_fk_filer_image_file_ptr_id` FOREIGN KEY (`image_id`) REFERENCES `filer_image` (`file_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3_bootstr_link_file_id_255a0b6d_fk_filer_file_id` FOREIGN KEY (`link_file_id`) REFERENCES `filer_file` (`id`),
  CONSTRAINT `aldryn_bootstrap3_bootstrap3_link_page_id_72e34b6_fk_cms_page_id` FOREIGN KEY (`link_page_id`) REFERENCES `cms_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_bootstrap3carouselslideplugin`
--

LOCK TABLES `aldryn_bootstrap3_bootstrap3carouselslideplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3carouselslideplugin` DISABLE KEYS */;
INSERT INTO `aldryn_bootstrap3_bootstrap3carouselslideplugin` VALUES (119,'','nova-diretoria','','','_blank','','','',1,NULL,NULL,'{}'),(128,'','','','','','Filie-se, é rápido e fácil','','',2,NULL,3,'{}'),(137,'','','','','','','','',3,NULL,NULL,'{}'),(170,'','nova-diretoria','','','_blank','','','',1,NULL,NULL,'{}'),(179,'','','','','','Filie-se, é rápido e fácil','','',2,NULL,3,'{}'),(188,'','','','','','','','',3,NULL,NULL,'{}');
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3carouselslideplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_bootstrap3columnplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_bootstrap3columnplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_bootstrap3columnplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `classes` longtext NOT NULL,
  `tag` varchar(50) NOT NULL,
  `xs_col` int(11) DEFAULT NULL,
  `xs_offset` int(11) DEFAULT NULL,
  `xs_push` int(11) DEFAULT NULL,
  `xs_pull` int(11) DEFAULT NULL,
  `sm_col` int(11) DEFAULT NULL,
  `sm_offset` int(11) DEFAULT NULL,
  `sm_push` int(11) DEFAULT NULL,
  `sm_pull` int(11) DEFAULT NULL,
  `md_col` int(11) DEFAULT NULL,
  `md_offset` int(11) DEFAULT NULL,
  `md_push` int(11) DEFAULT NULL,
  `md_pull` int(11) DEFAULT NULL,
  `lg_col` int(11) DEFAULT NULL,
  `lg_offset` int(11) DEFAULT NULL,
  `lg_push` int(11) DEFAULT NULL,
  `lg_pull` int(11) DEFAULT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `aldryn_bootstrap3_bootstrap3columnplugin_e4d23e84` (`tag`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_1aee1f75_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_bootstrap3columnplugin`
--

LOCK TABLES `aldryn_bootstrap3_bootstrap3columnplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3columnplugin` DISABLE KEYS */;
INSERT INTO `aldryn_bootstrap3_bootstrap3columnplugin` VALUES (122,'','div',12,NULL,NULL,NULL,12,NULL,NULL,NULL,12,NULL,NULL,NULL,12,NULL,NULL,NULL),(131,'','div',12,NULL,NULL,NULL,12,NULL,NULL,NULL,12,NULL,NULL,NULL,12,NULL,NULL,NULL),(140,'','div',12,NULL,NULL,NULL,12,NULL,NULL,NULL,12,NULL,NULL,NULL,12,NULL,NULL,NULL),(173,'','div',12,NULL,NULL,NULL,12,NULL,NULL,NULL,12,NULL,NULL,NULL,12,NULL,NULL,NULL),(182,'','div',12,NULL,NULL,NULL,12,NULL,NULL,NULL,12,NULL,NULL,NULL,12,NULL,NULL,NULL),(191,'','div',12,NULL,NULL,NULL,12,NULL,NULL,NULL,12,NULL,NULL,NULL,12,NULL,NULL,NULL);
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3columnplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_bootstrap3fileplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_bootstrap3fileplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_bootstrap3fileplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `name` longtext NOT NULL,
  `open_new_window` tinyint(1) NOT NULL,
  `show_file_size` tinyint(1) NOT NULL,
  `icon_left` varchar(255) NOT NULL,
  `icon_right` varchar(255) NOT NULL,
  `classes` longtext NOT NULL,
  `file_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `aldryn_bootstrap3_bootstrap3fileplugin_814552b9` (`file_id`),
  CONSTRAINT `aldryn_bootstrap3_b_cmsplugin_ptr_id_695f035_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`),
  CONSTRAINT `aldryn_bootstrap3_bootstrap3fi_file_id_5e6a0cb7_fk_filer_file_id` FOREIGN KEY (`file_id`) REFERENCES `filer_file` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_bootstrap3fileplugin`
--

LOCK TABLES `aldryn_bootstrap3_bootstrap3fileplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3fileplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3fileplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_bootstrap3listgroupitemplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_bootstrap3listgroupitemplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_bootstrap3listgroupitemplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `title` longtext NOT NULL,
  `context` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_456d15d0_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_bootstrap3listgroupitemplugin`
--

LOCK TABLES `aldryn_bootstrap3_bootstrap3listgroupitemplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3listgroupitemplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3listgroupitemplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_bootstrap3listgroupplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_bootstrap3listgroupplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_bootstrap3listgroupplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `classes` longtext NOT NULL,
  `add_list_group_class` tinyint(1) NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_13e817ef_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_bootstrap3listgroupplugin`
--

LOCK TABLES `aldryn_bootstrap3_bootstrap3listgroupplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3listgroupplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3listgroupplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_bootstrap3_bootstrap3rowplugin`
--

DROP TABLE IF EXISTS `aldryn_bootstrap3_bootstrap3rowplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_bootstrap3_bootstrap3rowplugin` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `classes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_bootstrap3__cmsplugin_ptr_id_68d2fd4a_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_bootstrap3_bootstrap3rowplugin`
--

LOCK TABLES `aldryn_bootstrap3_bootstrap3rowplugin` WRITE;
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3rowplugin` DISABLE KEYS */;
INSERT INTO `aldryn_bootstrap3_bootstrap3rowplugin` VALUES (121,'row slide-margin'),(130,'row slide-margin'),(139,'row slide-margin'),(172,'row slide-margin'),(181,'row slide-margin'),(190,'row slide-margin');
/*!40000 ALTER TABLE `aldryn_bootstrap3_bootstrap3rowplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aldryn_style_style`
--

DROP TABLE IF EXISTS `aldryn_style_style`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aldryn_style_style` (
  `label` varchar(128) NOT NULL,
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `id_name` varchar(50) NOT NULL,
  `tag_type` varchar(50) NOT NULL,
  `padding_left` smallint(6) DEFAULT NULL,
  `padding_right` smallint(6) DEFAULT NULL,
  `padding_top` smallint(6) DEFAULT NULL,
  `padding_bottom` smallint(6) DEFAULT NULL,
  `margin_left` smallint(6) DEFAULT NULL,
  `margin_right` smallint(6) DEFAULT NULL,
  `margin_top` smallint(6) DEFAULT NULL,
  `margin_bottom` smallint(6) DEFAULT NULL,
  `additional_class_names` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `aldryn_style_style_cmsplugin_ptr_id_36c654c0_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aldryn_style_style`
--

LOCK TABLES `aldryn_style_style` WRITE;
/*!40000 ALTER TABLE `aldryn_style_style` DISABLE KEYS */;
INSERT INTO `aldryn_style_style` VALUES ('carousel-container',120,'','','div',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('',123,'','','div',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'carousel-content'),('carousel-container',129,'','','div',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('',132,'','','div',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'carousel-content'),('carousel-container',138,'','','div',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('',141,'','','div',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'carousel-content'),('carousel-container',171,'','','div',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('',174,'','','div',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'carousel-content'),('carousel-container',180,'','','div',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('',183,'','','div',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'carousel-content'),('carousel-container',189,'','','div',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('',192,'','','div',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'carousel-content');
/*!40000 ALTER TABLE `aldryn_style_style` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissi_permission_id_23962d04_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_group_permissi_permission_id_23962d04_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_58c48ba9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permissi_content_type_id_51277a81_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can use Structure mode',1,'use_structure'),(2,'Can change page',2,'change_page'),(3,'Can add permission',3,'add_permission'),(4,'Can change permission',3,'change_permission'),(5,'Can delete permission',3,'delete_permission'),(6,'Can add group',4,'add_group'),(7,'Can change group',4,'change_group'),(8,'Can delete group',4,'delete_group'),(9,'Can add user',5,'add_user'),(10,'Can change user',5,'change_user'),(11,'Can delete user',5,'delete_user'),(12,'Can add content type',6,'add_contenttype'),(13,'Can change content type',6,'change_contenttype'),(14,'Can delete content type',6,'delete_contenttype'),(15,'Can add session',7,'add_session'),(16,'Can change session',7,'change_session'),(17,'Can delete session',7,'delete_session'),(18,'Can add log entry',8,'add_logentry'),(19,'Can change log entry',8,'change_logentry'),(20,'Can delete log entry',8,'delete_logentry'),(21,'Can add site',9,'add_site'),(22,'Can change site',9,'change_site'),(23,'Can delete site',9,'delete_site'),(24,'Can add user setting',10,'add_usersettings'),(25,'Can change user setting',10,'change_usersettings'),(26,'Can delete user setting',10,'delete_usersettings'),(27,'Can add page',2,'add_page'),(28,'Can delete page',2,'delete_page'),(29,'Can view page',2,'view_page'),(30,'Can publish page',2,'publish_page'),(31,'Can edit static placeholders',2,'edit_static_placeholder'),(32,'Can add Page global permission',11,'add_globalpagepermission'),(33,'Can change Page global permission',11,'change_globalpagepermission'),(34,'Can delete Page global permission',11,'delete_globalpagepermission'),(35,'Can add Page permission',12,'add_pagepermission'),(36,'Can change Page permission',12,'change_pagepermission'),(37,'Can delete Page permission',12,'delete_pagepermission'),(38,'Can add User (page)',13,'add_pageuser'),(39,'Can change User (page)',13,'change_pageuser'),(40,'Can delete User (page)',13,'delete_pageuser'),(41,'Can add User group (page)',14,'add_pageusergroup'),(42,'Can change User group (page)',14,'change_pageusergroup'),(43,'Can delete User group (page)',14,'delete_pageusergroup'),(44,'Can add placeholder',1,'add_placeholder'),(45,'Can change placeholder',1,'change_placeholder'),(46,'Can delete placeholder',1,'delete_placeholder'),(47,'Can add cms plugin',15,'add_cmsplugin'),(48,'Can change cms plugin',15,'change_cmsplugin'),(49,'Can delete cms plugin',15,'delete_cmsplugin'),(50,'Can add title',16,'add_title'),(51,'Can change title',16,'change_title'),(52,'Can delete title',16,'delete_title'),(53,'Can add placeholder reference',17,'add_placeholderreference'),(54,'Can change placeholder reference',17,'change_placeholderreference'),(55,'Can delete placeholder reference',17,'delete_placeholderreference'),(56,'Can add static placeholder',18,'add_staticplaceholder'),(57,'Can change static placeholder',18,'change_staticplaceholder'),(58,'Can delete static placeholder',18,'delete_staticplaceholder'),(59,'Can add alias plugin model',19,'add_aliaspluginmodel'),(60,'Can change alias plugin model',19,'change_aliaspluginmodel'),(61,'Can delete alias plugin model',19,'delete_aliaspluginmodel'),(62,'Can add urlconf revision',20,'add_urlconfrevision'),(63,'Can change urlconf revision',20,'change_urlconfrevision'),(64,'Can delete urlconf revision',20,'delete_urlconfrevision'),(65,'Can add cache key',21,'add_cachekey'),(66,'Can change cache key',21,'change_cachekey'),(67,'Can delete cache key',21,'delete_cachekey'),(68,'Can add text',22,'add_text'),(69,'Can change text',22,'change_text'),(70,'Can delete text',22,'delete_text'),(71,'Can add Folder',23,'add_folder'),(72,'Can change Folder',23,'change_folder'),(73,'Can delete Folder',23,'delete_folder'),(74,'Can use directory listing',23,'can_use_directory_listing'),(75,'Can add folder permission',24,'add_folderpermission'),(76,'Can change folder permission',24,'change_folderpermission'),(77,'Can delete folder permission',24,'delete_folderpermission'),(78,'Can add file',25,'add_file'),(79,'Can change file',25,'change_file'),(80,'Can delete file',25,'delete_file'),(81,'Can add clipboard',26,'add_clipboard'),(82,'Can change clipboard',26,'change_clipboard'),(83,'Can delete clipboard',26,'delete_clipboard'),(84,'Can add clipboard item',27,'add_clipboarditem'),(85,'Can change clipboard item',27,'change_clipboarditem'),(86,'Can delete clipboard item',27,'delete_clipboarditem'),(87,'Can add image',28,'add_image'),(88,'Can change image',28,'change_image'),(89,'Can delete image',28,'delete_image'),(90,'Can add thumbnail option',29,'add_thumbnailoption'),(91,'Can change thumbnail option',29,'change_thumbnailoption'),(92,'Can delete thumbnail option',29,'delete_thumbnailoption'),(93,'Can add source',30,'add_source'),(94,'Can change source',30,'change_source'),(95,'Can delete source',30,'delete_source'),(96,'Can add thumbnail',31,'add_thumbnail'),(97,'Can change thumbnail',31,'change_thumbnail'),(98,'Can delete thumbnail',31,'delete_thumbnail'),(99,'Can add thumbnail dimensions',32,'add_thumbnaildimensions'),(100,'Can change thumbnail dimensions',32,'change_thumbnaildimensions'),(101,'Can delete thumbnail dimensions',32,'delete_thumbnaildimensions'),(102,'Can add multi columns',33,'add_multicolumns'),(103,'Can change multi columns',33,'change_multicolumns'),(104,'Can delete multi columns',33,'delete_multicolumns'),(105,'Can add column',34,'add_column'),(106,'Can change column',34,'change_column'),(107,'Can delete column',34,'delete_column'),(108,'Can add link',35,'add_link'),(109,'Can change link',35,'change_link'),(110,'Can delete link',35,'delete_link'),(111,'Can add filer file',36,'add_filerfile'),(112,'Can change filer file',36,'change_filerfile'),(113,'Can delete filer file',36,'delete_filerfile'),(114,'Can add filer folder',37,'add_filerfolder'),(115,'Can change filer folder',37,'change_filerfolder'),(116,'Can delete filer folder',37,'delete_filerfolder'),(117,'Can add filer image',38,'add_filerimage'),(118,'Can change filer image',38,'change_filerimage'),(119,'Can delete filer image',38,'delete_filerimage'),(120,'Can add style',39,'add_style'),(121,'Can change style',39,'change_style'),(122,'Can delete style',39,'delete_style'),(123,'Can add Snippet',40,'add_snippet'),(124,'Can change Snippet',40,'change_snippet'),(125,'Can delete Snippet',40,'delete_snippet'),(126,'Can add Snippet',41,'add_snippetptr'),(127,'Can change Snippet',41,'change_snippetptr'),(128,'Can delete Snippet',41,'delete_snippetptr'),(129,'Can add google map',42,'add_googlemap'),(130,'Can change google map',42,'change_googlemap'),(131,'Can delete google map',42,'delete_googlemap'),(132,'Can add google map marker',43,'add_googlemapmarker'),(133,'Can change google map marker',43,'change_googlemapmarker'),(134,'Can delete google map marker',43,'delete_googlemapmarker'),(135,'Can add google map route',44,'add_googlemaproute'),(136,'Can change google map route',44,'change_googlemaproute'),(137,'Can delete google map route',44,'delete_googlemaproute'),(138,'Can add video player',45,'add_videoplayer'),(139,'Can change video player',45,'change_videoplayer'),(140,'Can delete video player',45,'delete_videoplayer'),(141,'Can add video source',46,'add_videosource'),(142,'Can change video source',46,'change_videosource'),(143,'Can delete video source',46,'delete_videosource'),(144,'Can add video track',47,'add_videotrack'),(145,'Can change video track',47,'change_videotrack'),(146,'Can delete video track',47,'delete_videotrack'),(147,'Can add style',48,'add_style'),(148,'Can change style',48,'change_style'),(149,'Can delete style',48,'delete_style'),(150,'Can add boostrap3 button plugin',49,'add_boostrap3buttonplugin'),(151,'Can change boostrap3 button plugin',49,'change_boostrap3buttonplugin'),(152,'Can delete boostrap3 button plugin',49,'delete_boostrap3buttonplugin'),(153,'Can add boostrap3 blockquote plugin',50,'add_boostrap3blockquoteplugin'),(154,'Can change boostrap3 blockquote plugin',50,'change_boostrap3blockquoteplugin'),(155,'Can delete boostrap3 blockquote plugin',50,'delete_boostrap3blockquoteplugin'),(156,'Can add boostrap3 icon plugin',51,'add_boostrap3iconplugin'),(157,'Can change boostrap3 icon plugin',51,'change_boostrap3iconplugin'),(158,'Can delete boostrap3 icon plugin',51,'delete_boostrap3iconplugin'),(159,'Can add boostrap3 label plugin',52,'add_boostrap3labelplugin'),(160,'Can change boostrap3 label plugin',52,'change_boostrap3labelplugin'),(161,'Can delete boostrap3 label plugin',52,'delete_boostrap3labelplugin'),(162,'Can add boostrap3 well plugin',53,'add_boostrap3wellplugin'),(163,'Can change boostrap3 well plugin',53,'change_boostrap3wellplugin'),(164,'Can delete boostrap3 well plugin',53,'delete_boostrap3wellplugin'),(165,'Can add boostrap3 alert plugin',54,'add_boostrap3alertplugin'),(166,'Can change boostrap3 alert plugin',54,'change_boostrap3alertplugin'),(167,'Can delete boostrap3 alert plugin',54,'delete_boostrap3alertplugin'),(168,'Can add boostrap3 image plugin',55,'add_boostrap3imageplugin'),(169,'Can change boostrap3 image plugin',55,'change_boostrap3imageplugin'),(170,'Can delete boostrap3 image plugin',55,'delete_boostrap3imageplugin'),(171,'Can add boostrap3 spacer plugin',56,'add_boostrap3spacerplugin'),(172,'Can change boostrap3 spacer plugin',56,'change_boostrap3spacerplugin'),(173,'Can delete boostrap3 spacer plugin',56,'delete_boostrap3spacerplugin'),(174,'Can add bootstrap3 file plugin',57,'add_bootstrap3fileplugin'),(175,'Can change bootstrap3 file plugin',57,'change_bootstrap3fileplugin'),(176,'Can delete bootstrap3 file plugin',57,'delete_bootstrap3fileplugin'),(177,'Can add boostrap3 panel plugin',58,'add_boostrap3panelplugin'),(178,'Can change boostrap3 panel plugin',58,'change_boostrap3panelplugin'),(179,'Can delete boostrap3 panel plugin',58,'delete_boostrap3panelplugin'),(180,'Can add boostrap3 panel heading plugin',59,'add_boostrap3panelheadingplugin'),(181,'Can change boostrap3 panel heading plugin',59,'change_boostrap3panelheadingplugin'),(182,'Can delete boostrap3 panel heading plugin',59,'delete_boostrap3panelheadingplugin'),(183,'Can add boostrap3 panel body plugin',60,'add_boostrap3panelbodyplugin'),(184,'Can change boostrap3 panel body plugin',60,'change_boostrap3panelbodyplugin'),(185,'Can delete boostrap3 panel body plugin',60,'delete_boostrap3panelbodyplugin'),(186,'Can add boostrap3 panel footer plugin',61,'add_boostrap3panelfooterplugin'),(187,'Can change boostrap3 panel footer plugin',61,'change_boostrap3panelfooterplugin'),(188,'Can delete boostrap3 panel footer plugin',61,'delete_boostrap3panelfooterplugin'),(189,'Can add bootstrap3 row plugin',62,'add_bootstrap3rowplugin'),(190,'Can change bootstrap3 row plugin',62,'change_bootstrap3rowplugin'),(191,'Can delete bootstrap3 row plugin',62,'delete_bootstrap3rowplugin'),(192,'Can add bootstrap3 column plugin',63,'add_bootstrap3columnplugin'),(193,'Can change bootstrap3 column plugin',63,'change_bootstrap3columnplugin'),(194,'Can delete bootstrap3 column plugin',63,'delete_bootstrap3columnplugin'),(195,'Can add bootstrap3 accordion plugin',64,'add_bootstrap3accordionplugin'),(196,'Can change bootstrap3 accordion plugin',64,'change_bootstrap3accordionplugin'),(197,'Can delete bootstrap3 accordion plugin',64,'delete_bootstrap3accordionplugin'),(198,'Can add bootstrap3 accordion item plugin',65,'add_bootstrap3accordionitemplugin'),(199,'Can change bootstrap3 accordion item plugin',65,'change_bootstrap3accordionitemplugin'),(200,'Can delete bootstrap3 accordion item plugin',65,'delete_bootstrap3accordionitemplugin'),(201,'Can add bootstrap3 list group plugin',66,'add_bootstrap3listgroupplugin'),(202,'Can change bootstrap3 list group plugin',66,'change_bootstrap3listgroupplugin'),(203,'Can delete bootstrap3 list group plugin',66,'delete_bootstrap3listgroupplugin'),(204,'Can add bootstrap3 list group item plugin',67,'add_bootstrap3listgroupitemplugin'),(205,'Can change bootstrap3 list group item plugin',67,'change_bootstrap3listgroupitemplugin'),(206,'Can delete bootstrap3 list group item plugin',67,'delete_bootstrap3listgroupitemplugin'),(207,'Can add bootstrap3 carousel plugin',68,'add_bootstrap3carouselplugin'),(208,'Can change bootstrap3 carousel plugin',68,'change_bootstrap3carouselplugin'),(209,'Can delete bootstrap3 carousel plugin',68,'delete_bootstrap3carouselplugin'),(210,'Can add bootstrap3 carousel slide plugin',69,'add_bootstrap3carouselslideplugin'),(211,'Can change bootstrap3 carousel slide plugin',69,'change_bootstrap3carouselslideplugin'),(212,'Can delete bootstrap3 carousel slide plugin',69,'delete_bootstrap3carouselslideplugin'),(213,'Can add bootstrap3 carousel slide folder plugin',70,'add_bootstrap3carouselslidefolderplugin'),(214,'Can change bootstrap3 carousel slide folder plugin',70,'change_bootstrap3carouselslidefolderplugin'),(215,'Can delete bootstrap3 carousel slide folder plugin',70,'delete_bootstrap3carouselslidefolderplugin');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$20000$JzIqdJOdz8u3$dxfnwjJeoll9hJJ7eVwHMKxhqfxFVIbxYKfYix8pY9s=','2016-12-24 14:26:41.164000',1,'admin','','','admin@admin.com',1,1,'2016-12-20 23:33:11.138000');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_30a071c9_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_30a071c9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_24702650_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_perm_permission_id_3d7071f0_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_user_user_perm_permission_id_3d7071f0_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_7cd7acb6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_aliaspluginmodel`
--

DROP TABLE IF EXISTS `cms_aliaspluginmodel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_aliaspluginmodel` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `plugin_id` int(11) DEFAULT NULL,
  `alias_placeholder_id` int(11),
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `cms_aliaspluginmodel_921abf5c` (`alias_placeholder_id`),
  KEY `cms_aliaspluginmodel_plugin_id_2e7b802f_fk_cms_cmsplugin_id` (`plugin_id`),
  CONSTRAINT `cms_aliasplu_alias_placeholder_id_49af9083_fk_cms_placeholder_id` FOREIGN KEY (`alias_placeholder_id`) REFERENCES `cms_placeholder` (`id`),
  CONSTRAINT `cms_aliaspluginmod_cmsplugin_ptr_id_5b59cb3c_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`),
  CONSTRAINT `cms_aliaspluginmodel_plugin_id_2e7b802f_fk_cms_cmsplugin_id` FOREIGN KEY (`plugin_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_aliaspluginmodel`
--

LOCK TABLES `cms_aliaspluginmodel` WRITE;
/*!40000 ALTER TABLE `cms_aliaspluginmodel` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_aliaspluginmodel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_cmsplugin`
--

DROP TABLE IF EXISTS `cms_cmsplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_cmsplugin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` smallint(5) unsigned NOT NULL,
  `language` varchar(15) NOT NULL,
  `plugin_type` varchar(50) NOT NULL,
  `creation_date` datetime(6) NOT NULL,
  `changed_date` datetime(6) NOT NULL,
  `parent_id` int(11),
  `placeholder_id` int(11),
  `depth` int(10) unsigned NOT NULL,
  `numchild` int(10) unsigned NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cms_cmsplugin_path_7d5df9d5_uniq` (`path`),
  KEY `cms_cmsplugin_8512ae7d` (`language`),
  KEY `cms_cmsplugin_b5e4cf8f` (`plugin_type`),
  KEY `cms_cmsplugin_6be37982` (`parent_id`),
  KEY `cms_cmsplugin_667a6151` (`placeholder_id`),
  CONSTRAINT `cms_cmsplugin_parent_id_2b89b923_fk_cms_cmsplugin_id` FOREIGN KEY (`parent_id`) REFERENCES `cms_cmsplugin` (`id`),
  CONSTRAINT `cms_cmsplugin_placeholder_id_41cb13f1_fk_cms_placeholder_id` FOREIGN KEY (`placeholder_id`) REFERENCES `cms_placeholder` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_cmsplugin`
--

LOCK TABLES `cms_cmsplugin` WRITE;
/*!40000 ALTER TABLE `cms_cmsplugin` DISABLE KEYS */;
INSERT INTO `cms_cmsplugin` VALUES (5,0,'pt-br','TextPlugin','2016-12-21 15:45:16.781000','2016-12-21 15:47:00.187000',NULL,4,1,0,'0002'),(16,0,'pt-br','TextPlugin','2016-12-21 15:45:16.781000','2016-12-21 18:32:03.132000',NULL,5,1,0,'0005'),(118,0,'pt-br','Bootstrap3CarouselCMSPlugin','2016-12-21 17:46:15.151000','2016-12-23 14:38:22.009000',NULL,19,1,3,'000A'),(119,0,'pt-br','Bootstrap3CarouselSlideCMSPlugin','2016-12-21 17:54:01.203000','2016-12-22 17:41:33.609000',118,19,2,1,'000A0001'),(120,0,'pt-br','StylePlugin','2016-12-21 21:10:59.032000','2016-12-22 17:41:33.719000',119,19,3,1,'000A00010001'),(121,0,'pt-br','Bootstrap3RowCMSPlugin','2016-12-21 21:13:23.681000','2016-12-22 17:41:33.844000',120,19,4,1,'000A000100010001'),(122,0,'pt-br','Bootstrap3ColumnCMSPlugin','2016-12-21 21:13:23.702000','2016-12-22 17:41:33.951000',121,19,5,1,'000A0001000100010001'),(123,0,'pt-br','StylePlugin','2016-12-21 21:14:33.718000','2016-12-22 17:41:34.066000',122,19,6,4,'000A00010001000100010001'),(124,0,'pt-br','TextPlugin','2016-12-22 17:41:34.151000','2016-12-22 17:41:34.195000',123,19,7,0,'000A000100010001000100010001'),(125,0,'pt-br','TextPlugin','2016-12-22 17:41:34.244000','2016-12-22 17:41:34.285000',123,19,7,0,'000A000100010001000100010002'),(126,2,'pt-br','TextPlugin','2016-12-21 23:04:46.897000','2016-12-22 17:41:37.258000',123,19,7,0,'000A000100010001000100010003'),(127,3,'pt-br','Bootstrap3ButtonCMSPlugin','2016-12-21 23:09:35.107000','2016-12-22 17:41:34.621000',123,19,7,0,'000A000100010001000100010004'),(128,1,'pt-br','Bootstrap3CarouselSlideCMSPlugin','2016-12-21 18:24:53.664000','2016-12-22 17:41:34.775000',118,19,2,1,'000A0002'),(129,0,'pt-br','StylePlugin','2016-12-21 21:10:59.032000','2016-12-22 17:41:34.931000',128,19,3,1,'000A00020001'),(130,0,'pt-br','Bootstrap3RowCMSPlugin','2016-12-21 21:13:23.681000','2016-12-22 17:41:35.076000',129,19,4,1,'000A000200010001'),(131,0,'pt-br','Bootstrap3ColumnCMSPlugin','2016-12-21 21:13:23.702000','2016-12-22 17:41:35.276000',130,19,5,1,'000A0002000100010001'),(132,0,'pt-br','StylePlugin','2016-12-21 21:14:33.718000','2016-12-22 17:41:35.409000',131,19,6,4,'000A00020001000100010001'),(133,0,'pt-br','TextPlugin','2016-12-22 17:41:35.440000','2016-12-22 17:41:35.471000',132,19,7,0,'000A000200010001000100010001'),(134,0,'pt-br','TextPlugin','2016-12-22 17:41:35.518000','2016-12-22 17:41:35.545000',132,19,7,0,'000A000200010001000100010002'),(135,2,'pt-br','TextPlugin','2016-12-21 23:04:46.897000','2016-12-22 17:41:37.354000',132,19,7,0,'000A000200010001000100010003'),(136,3,'pt-br','Bootstrap3ButtonCMSPlugin','2016-12-21 23:09:35.107000','2016-12-22 17:41:35.953000',132,19,7,0,'000A000200010001000100010004'),(137,2,'pt-br','Bootstrap3CarouselSlideCMSPlugin','2016-12-21 18:27:19.833000','2016-12-22 17:41:36.210000',118,19,2,1,'000A0003'),(138,0,'pt-br','StylePlugin','2016-12-21 21:10:59.032000','2016-12-22 17:41:36.333000',137,19,3,1,'000A00030001'),(139,0,'pt-br','Bootstrap3RowCMSPlugin','2016-12-21 21:13:23.681000','2016-12-22 17:41:36.452000',138,19,4,1,'000A000300010001'),(140,0,'pt-br','Bootstrap3ColumnCMSPlugin','2016-12-21 21:13:23.702000','2016-12-22 17:41:36.575000',139,19,5,1,'000A0003000100010001'),(141,0,'pt-br','StylePlugin','2016-12-21 21:14:33.718000','2016-12-22 17:41:36.689000',140,19,6,4,'000A00030001000100010001'),(142,0,'pt-br','TextPlugin','2016-12-22 17:41:36.755000','2016-12-22 17:41:36.781000',141,19,7,0,'000A000300010001000100010001'),(143,0,'pt-br','TextPlugin','2016-12-22 17:41:36.817000','2016-12-22 17:41:36.865000',141,19,7,0,'000A000300010001000100010002'),(144,2,'pt-br','TextPlugin','2016-12-21 23:04:46.897000','2016-12-23 14:19:21.878000',141,19,7,0,'000A000300010001000100010003'),(145,3,'pt-br','Bootstrap3ButtonCMSPlugin','2016-12-21 23:09:35.107000','2016-12-22 17:41:37.182000',141,19,7,0,'000A000300010001000100010004'),(146,0,'pt-br','Bootstrap3IconCMSPlugin','2016-12-22 17:42:40.152000','2016-12-22 18:00:21.577000',149,20,2,0,'000E0002'),(147,1,'pt-br','TextPlugin','2016-12-22 17:42:59.021000','2016-12-22 18:22:19.588000',149,20,2,0,'000E0001'),(148,0,'pt-br','TextPlugin','2016-12-22 17:54:24.742000','2016-12-22 18:21:51.396000',NULL,21,1,0,'000D'),(149,2,'pt-br','LinkPlugin','2016-12-22 17:59:35.160000','2016-12-22 17:59:35.182000',NULL,20,1,2,'000E'),(150,2,'pt-br','LinkPlugin','2016-12-22 17:59:35.160000','2016-12-22 18:41:11.156000',NULL,1,1,2,'000F'),(151,1,'pt-br','TextPlugin','2016-12-22 17:42:59.021000','2016-12-22 18:41:11.317000',150,1,2,0,'000F0001'),(152,0,'pt-br','Bootstrap3IconCMSPlugin','2016-12-22 17:42:40.152000','2016-12-22 18:41:11.286000',150,1,2,0,'000F0002'),(153,0,'pt-br','LinkPlugin','2016-12-22 17:59:35.160000','2016-12-22 18:43:56.923000',NULL,22,1,2,'000G'),(154,1,'pt-br','TextPlugin','2016-12-22 17:42:59.021000','2016-12-22 19:19:43.553000',153,22,2,0,'000G0001'),(155,0,'pt-br','Bootstrap3IconCMSPlugin','2016-12-22 17:42:40.152000','2016-12-22 18:45:28.792000',153,22,2,0,'000G0002'),(156,0,'pt-br','LinkPlugin','2016-12-22 17:59:35.160000','2016-12-22 18:47:30.680000',NULL,23,1,2,'000H'),(157,1,'pt-br','TextPlugin','2016-12-22 17:42:59.021000','2016-12-22 18:49:32.862000',156,23,2,0,'000H0001'),(158,0,'pt-br','Bootstrap3IconCMSPlugin','2016-12-22 17:42:40.152000','2016-12-22 18:48:01.284000',156,23,2,0,'000H0002'),(159,0,'pt-br','LinkPlugin','2016-12-22 17:59:35.160000','2016-12-22 19:05:57.564000',NULL,24,1,2,'000I'),(160,1,'pt-br','TextPlugin','2016-12-22 17:42:59.021000','2016-12-23 14:22:03.212000',159,24,2,0,'000I0001'),(161,0,'pt-br','Bootstrap3IconCMSPlugin','2016-12-22 17:42:40.152000','2016-12-22 19:06:29.492000',159,24,2,0,'000I0002'),(162,0,'pt-br','LinkPlugin','2016-12-22 17:59:35.160000','2016-12-22 19:12:16.170000',NULL,25,1,2,'000J'),(163,1,'pt-br','TextPlugin','2016-12-22 17:42:59.021000','2016-12-22 19:14:26.487000',162,25,2,0,'000J0001'),(164,0,'pt-br','Bootstrap3IconCMSPlugin','2016-12-22 17:42:40.152000','2016-12-22 19:25:34.354000',162,25,2,0,'000J0002'),(165,0,'pt-br','LinkPlugin','2016-12-22 17:59:35.160000','2016-12-22 19:04:40.278000',NULL,26,1,2,'000K'),(166,1,'pt-br','TextPlugin','2016-12-22 17:42:59.021000','2016-12-22 19:05:35.652000',165,26,2,0,'000K0001'),(167,0,'pt-br','Bootstrap3IconCMSPlugin','2016-12-22 17:42:40.152000','2016-12-22 19:11:44.724000',165,26,2,0,'000K0002'),(168,0,'pt-br','TextPlugin','2016-12-23 13:19:03.263000','2016-12-23 13:23:38.372000',NULL,29,1,0,'000L'),(169,0,'pt-br','Bootstrap3CarouselCMSPlugin','2016-12-21 17:46:15.151000','2016-12-23 16:45:42.162000',NULL,39,1,3,'000M'),(170,0,'pt-br','Bootstrap3CarouselSlideCMSPlugin','2016-12-21 17:54:01.203000','2016-12-23 16:45:42.299000',169,39,2,1,'000M0001'),(171,0,'pt-br','StylePlugin','2016-12-21 21:10:59.032000','2016-12-23 16:45:42.342000',170,39,3,1,'000M00010001'),(172,0,'pt-br','Bootstrap3RowCMSPlugin','2016-12-21 21:13:23.681000','2016-12-23 16:45:42.381000',171,39,4,1,'000M000100010001'),(173,0,'pt-br','Bootstrap3ColumnCMSPlugin','2016-12-21 21:13:23.702000','2016-12-23 16:45:42.441000',172,39,5,1,'000M0001000100010001'),(174,0,'pt-br','StylePlugin','2016-12-21 21:14:33.718000','2016-12-23 16:45:42.551000',173,39,6,4,'000M00010001000100010001'),(175,0,'pt-br','TextPlugin','2016-12-23 16:45:42.570000','2016-12-23 16:45:42.579000',174,39,7,0,'000M000100010001000100010001'),(176,0,'pt-br','TextPlugin','2016-12-23 16:45:42.589000','2016-12-23 16:45:42.604000',174,39,7,0,'000M000100010001000100010002'),(177,2,'pt-br','TextPlugin','2016-12-21 23:04:46.897000','2016-12-23 16:45:43.512000',174,39,7,0,'000M000100010001000100010003'),(178,3,'pt-br','Bootstrap3ButtonCMSPlugin','2016-12-21 23:09:35.107000','2016-12-23 16:45:42.738000',174,39,7,0,'000M000100010001000100010004'),(179,1,'pt-br','Bootstrap3CarouselSlideCMSPlugin','2016-12-21 18:24:53.664000','2016-12-23 16:45:42.789000',169,39,2,1,'000M0002'),(180,0,'pt-br','StylePlugin','2016-12-21 21:10:59.032000','2016-12-23 16:45:42.832000',179,39,3,1,'000M00020001'),(181,0,'pt-br','Bootstrap3RowCMSPlugin','2016-12-21 21:13:23.681000','2016-12-23 16:45:42.896000',180,39,4,1,'000M000200010001'),(182,0,'pt-br','Bootstrap3ColumnCMSPlugin','2016-12-21 21:13:23.702000','2016-12-23 16:45:42.936000',181,39,5,1,'000M0002000100010001'),(183,0,'pt-br','StylePlugin','2016-12-21 21:14:33.718000','2016-12-23 16:45:42.977000',182,39,6,4,'000M00020001000100010001'),(184,0,'pt-br','TextPlugin','2016-12-23 16:45:42.996000','2016-12-23 16:45:43.005000',183,39,7,0,'000M000200010001000100010001'),(185,0,'pt-br','TextPlugin','2016-12-23 16:45:43.014000','2016-12-23 16:45:43.029000',183,39,7,0,'000M000200010001000100010002'),(186,2,'pt-br','TextPlugin','2016-12-21 23:04:46.897000','2016-12-23 16:45:43.567000',183,39,7,0,'000M000200010001000100010003'),(187,3,'pt-br','Bootstrap3ButtonCMSPlugin','2016-12-21 23:09:35.107000','2016-12-23 16:45:43.129000',183,39,7,0,'000M000200010001000100010004'),(188,2,'pt-br','Bootstrap3CarouselSlideCMSPlugin','2016-12-21 18:27:19.833000','2016-12-23 16:45:43.179000',169,39,2,1,'000M0003'),(189,0,'pt-br','StylePlugin','2016-12-21 21:10:59.032000','2016-12-23 16:45:43.220000',188,39,3,1,'000M00030001'),(190,0,'pt-br','Bootstrap3RowCMSPlugin','2016-12-21 21:13:23.681000','2016-12-23 16:45:43.255000',189,39,4,1,'000M000300010001'),(191,0,'pt-br','Bootstrap3ColumnCMSPlugin','2016-12-21 21:13:23.702000','2016-12-23 16:45:43.313000',190,39,5,1,'000M0003000100010001'),(192,0,'pt-br','StylePlugin','2016-12-21 21:14:33.718000','2016-12-23 16:45:43.345000',191,39,6,4,'000M00030001000100010001'),(193,0,'pt-br','TextPlugin','2016-12-23 16:45:43.359000','2016-12-23 16:45:43.365000',192,39,7,0,'000M000300010001000100010001'),(194,0,'pt-br','TextPlugin','2016-12-23 16:45:43.373000','2016-12-23 16:45:43.384000',192,39,7,0,'000M000300010001000100010002'),(195,2,'pt-br','TextPlugin','2016-12-21 23:04:46.897000','2016-12-23 16:45:43.624000',192,39,7,0,'000M000300010001000100010003'),(196,3,'pt-br','Bootstrap3ButtonCMSPlugin','2016-12-21 23:09:35.107000','2016-12-23 16:45:43.452000',192,39,7,0,'000M000300010001000100010004'),(197,2,'pt-br','LinkPlugin','2016-12-22 17:59:35.160000','2016-12-23 16:45:43.672000',NULL,41,1,2,'000N'),(198,1,'pt-br','TextPlugin','2016-12-22 17:42:59.021000','2016-12-23 16:45:43.764000',197,41,2,0,'000N0001'),(199,0,'pt-br','Bootstrap3IconCMSPlugin','2016-12-22 17:42:40.152000','2016-12-23 16:45:43.741000',197,41,2,0,'000N0002'),(200,0,'pt-br','TextPlugin','2016-12-22 17:54:24.742000','2016-12-23 16:45:43.827000',NULL,40,1,0,'000O'),(201,0,'pt-br','LinkPlugin','2016-12-22 17:59:35.160000','2016-12-23 16:45:43.872000',NULL,42,1,2,'000P'),(202,1,'pt-br','TextPlugin','2016-12-22 17:42:59.021000','2016-12-23 16:45:43.963000',201,42,2,0,'000P0001'),(203,0,'pt-br','Bootstrap3IconCMSPlugin','2016-12-22 17:42:40.152000','2016-12-23 16:45:43.942000',201,42,2,0,'000P0002'),(204,0,'pt-br','LinkPlugin','2016-12-22 17:59:35.160000','2016-12-23 16:45:44.010000',NULL,43,1,2,'000Q'),(205,1,'pt-br','TextPlugin','2016-12-22 17:42:59.021000','2016-12-23 16:45:44.090000',204,43,2,0,'000Q0001'),(206,0,'pt-br','Bootstrap3IconCMSPlugin','2016-12-22 17:42:40.152000','2016-12-23 16:45:44.068000',204,43,2,0,'000Q0002'),(207,0,'pt-br','LinkPlugin','2016-12-22 17:59:35.160000','2016-12-23 16:45:44.133000',NULL,44,1,2,'000R'),(208,1,'pt-br','TextPlugin','2016-12-22 17:42:59.021000','2016-12-23 16:45:44.207000',207,44,2,0,'000R0001'),(209,0,'pt-br','Bootstrap3IconCMSPlugin','2016-12-22 17:42:40.152000','2016-12-23 16:45:44.189000',207,44,2,0,'000R0002'),(210,0,'pt-br','LinkPlugin','2016-12-22 17:59:35.160000','2016-12-23 16:45:44.252000',NULL,45,1,2,'000S'),(211,1,'pt-br','TextPlugin','2016-12-22 17:42:59.021000','2016-12-23 16:45:44.379000',210,45,2,0,'000S0001'),(212,0,'pt-br','Bootstrap3IconCMSPlugin','2016-12-22 17:42:40.152000','2016-12-23 16:45:44.349000',210,45,2,0,'000S0002'),(213,0,'pt-br','LinkPlugin','2016-12-22 17:59:35.160000','2016-12-23 16:45:44.446000',NULL,46,1,2,'000T'),(214,1,'pt-br','TextPlugin','2016-12-22 17:42:59.021000','2016-12-23 16:45:44.565000',213,46,2,0,'000T0001'),(215,0,'pt-br','Bootstrap3IconCMSPlugin','2016-12-22 17:42:40.152000','2016-12-23 16:45:44.536000',213,46,2,0,'000T0002'),(216,0,'pt-br','TextPlugin','2016-12-23 13:19:03.263000','2016-12-23 16:45:44.647000',NULL,47,1,0,'000U');
/*!40000 ALTER TABLE `cms_cmsplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_globalpagepermission`
--

DROP TABLE IF EXISTS `cms_globalpagepermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_globalpagepermission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `can_change` tinyint(1) NOT NULL,
  `can_add` tinyint(1) NOT NULL,
  `can_delete` tinyint(1) NOT NULL,
  `can_change_advanced_settings` tinyint(1) NOT NULL,
  `can_publish` tinyint(1) NOT NULL,
  `can_change_permissions` tinyint(1) NOT NULL,
  `can_move_page` tinyint(1) NOT NULL,
  `can_view` tinyint(1) NOT NULL,
  `can_recover_page` tinyint(1) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_globalpagepermission_group_id_748ea6af_fk_auth_group_id` (`group_id`),
  KEY `cms_globalpagepermission_user_id_572f1d18_fk_auth_user_id` (`user_id`),
  CONSTRAINT `cms_globalpagepermission_group_id_748ea6af_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `cms_globalpagepermission_user_id_572f1d18_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_globalpagepermission`
--

LOCK TABLES `cms_globalpagepermission` WRITE;
/*!40000 ALTER TABLE `cms_globalpagepermission` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_globalpagepermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_globalpagepermission_sites`
--

DROP TABLE IF EXISTS `cms_globalpagepermission_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_globalpagepermission_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `globalpagepermission_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `globalpagepermission_id` (`globalpagepermission_id`,`site_id`),
  KEY `cms_globalpagepermission_site_site_id_618ef941_fk_django_site_id` (`site_id`),
  CONSTRAINT `cms_globalpagepermission_site_site_id_618ef941_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`),
  CONSTRAINT `globalpagepermission_id_31dcc6a9_fk_cms_globalpagepermission_id` FOREIGN KEY (`globalpagepermission_id`) REFERENCES `cms_globalpagepermission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_globalpagepermission_sites`
--

LOCK TABLES `cms_globalpagepermission_sites` WRITE;
/*!40000 ALTER TABLE `cms_globalpagepermission_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_globalpagepermission_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_page`
--

DROP TABLE IF EXISTS `cms_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) NOT NULL,
  `changed_by` varchar(255) NOT NULL,
  `creation_date` datetime(6) NOT NULL,
  `changed_date` datetime(6) NOT NULL,
  `publication_date` datetime(6) DEFAULT NULL,
  `publication_end_date` datetime(6) DEFAULT NULL,
  `in_navigation` tinyint(1) NOT NULL,
  `soft_root` tinyint(1) NOT NULL,
  `reverse_id` varchar(40) DEFAULT NULL,
  `navigation_extenders` varchar(80) DEFAULT NULL,
  `template` varchar(100) NOT NULL,
  `login_required` tinyint(1) NOT NULL,
  `limit_visibility_in_menu` smallint(6) DEFAULT NULL,
  `is_home` tinyint(1) NOT NULL,
  `application_urls` varchar(200) DEFAULT NULL,
  `application_namespace` varchar(200) DEFAULT NULL,
  `publisher_is_draft` tinyint(1) NOT NULL,
  `languages` varchar(255) DEFAULT NULL,
  `revision_id` int(10) unsigned NOT NULL,
  `xframe_options` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `publisher_public_id` int(11) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `depth` int(10) unsigned NOT NULL,
  `numchild` int(10) unsigned NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cms_page_path_78fc3e71_uniq` (`path`),
  UNIQUE KEY `publisher_public_id` (`publisher_public_id`),
  UNIQUE KEY `cms_page_reverse_id_42cae937_uniq` (`reverse_id`,`site_id`,`publisher_is_draft`),
  UNIQUE KEY `cms_page_publisher_is_draft_82d3aa_uniq` (`publisher_is_draft`,`site_id`,`application_namespace`),
  KEY `cms_page_parent_id_76fe1197_fk_cms_page_id` (`parent_id`),
  KEY `cms_page_site_id_7245e838_fk_django_site_id` (`site_id`),
  KEY `cms_page_93b83098` (`publication_date`),
  KEY `cms_page_2247c5f0` (`publication_end_date`),
  KEY `cms_page_db3eb53f` (`in_navigation`),
  KEY `cms_page_1d85575d` (`soft_root`),
  KEY `cms_page_3d9ef52f` (`reverse_id`),
  KEY `cms_page_7b8acfa6` (`navigation_extenders`),
  KEY `cms_page_cb540373` (`limit_visibility_in_menu`),
  KEY `cms_page_4fa1c803` (`is_home`),
  KEY `cms_page_e721871e` (`application_urls`),
  KEY `cms_page_b7700099` (`publisher_is_draft`),
  CONSTRAINT `cms_page_parent_id_76fe1197_fk_cms_page_id` FOREIGN KEY (`parent_id`) REFERENCES `cms_page` (`id`),
  CONSTRAINT `cms_page_publisher_public_id_27b14e29_fk_cms_page_id` FOREIGN KEY (`publisher_public_id`) REFERENCES `cms_page` (`id`),
  CONSTRAINT `cms_page_site_id_7245e838_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_page`
--

LOCK TABLES `cms_page` WRITE;
/*!40000 ALTER TABLE `cms_page` DISABLE KEYS */;
INSERT INTO `cms_page` VALUES (1,'script','admin','2016-12-21 11:50:23.871000','2016-12-24 14:32:58.740000','2016-12-21 11:50:32.954000',NULL,1,0,'home','','home.html',0,NULL,1,'',NULL,1,'pt-br',0,0,NULL,2,1,1,0,'0001'),(2,'script','admin','2016-12-21 11:50:32.969000','2016-12-24 14:31:10.451000','2016-12-21 11:50:32.954000',NULL,1,0,NULL,NULL,'home.html',0,NULL,1,'',NULL,0,'pt-br',0,0,NULL,1,1,1,0,'0002'),(3,'script','admin','2016-12-21 17:56:16.399000','2016-12-24 03:50:26.340000','2016-12-21 18:32:34.961000',NULL,1,0,NULL,'','filiacao.html',0,NULL,0,'',NULL,1,'pt-br',0,0,NULL,10,1,1,0,'0004'),(4,'script','admin','2016-12-21 17:59:09.298000','2016-12-21 18:32:38.714000','2016-12-21 18:32:37.823000',NULL,1,0,NULL,NULL,'home.html',0,NULL,0,NULL,NULL,1,'pt-br',0,0,NULL,11,1,1,0,'0007'),(5,'script','admin','2016-12-21 18:02:02.228000','2016-12-21 18:32:57.583000','2016-12-21 18:32:56.770000',NULL,1,0,NULL,NULL,'home.html',0,NULL,0,NULL,NULL,1,'pt-br',0,0,NULL,12,1,1,0,'0009'),(6,'script','admin','2016-12-21 18:02:51.948000','2016-12-21 18:33:06.957000','2016-12-21 18:33:06.504000',NULL,1,0,NULL,NULL,'INHERIT',0,NULL,0,NULL,NULL,1,'pt-br',0,0,NULL,13,1,1,0,'000B'),(7,'script','admin','2016-12-21 18:06:17.154000','2016-12-21 18:33:14.742000','2016-12-21 18:33:14.023000',NULL,1,0,NULL,'','home.html',0,NULL,0,'',NULL,1,'pt-br',0,0,NULL,14,1,1,0,'000D'),(9,'admin','admin','2016-12-21 18:08:23.660000','2016-12-21 18:33:36.912000','2016-12-21 18:33:36.469000',NULL,0,0,'page_types',NULL,'INHERIT',0,NULL,0,NULL,NULL,1,'pt-br',0,0,NULL,15,1,1,0,'000F'),(10,'admin','admin','2016-12-21 18:32:34.977000','2016-12-24 03:50:26.191000','2016-12-21 18:32:34.961000',NULL,1,0,NULL,'','filiacao.html',0,NULL,0,'',NULL,0,'pt-br',0,0,NULL,3,1,1,0,'0005'),(11,'admin','admin','2016-12-21 18:32:37.861000','2016-12-21 18:32:38.416000','2016-12-21 18:32:37.823000',NULL,1,0,NULL,NULL,'home.html',0,NULL,0,NULL,NULL,0,'pt-br',0,0,NULL,4,1,1,0,'0008'),(12,'admin','admin','2016-12-21 18:32:56.785000','2016-12-21 18:32:57.481000','2016-12-21 18:32:56.770000',NULL,1,0,NULL,NULL,'home.html',0,NULL,0,NULL,NULL,0,'pt-br',0,0,NULL,5,1,1,0,'000A'),(13,'admin','admin','2016-12-21 18:33:06.520000','2016-12-21 18:33:06.863000','2016-12-21 18:33:06.504000',NULL,1,0,NULL,NULL,'INHERIT',0,NULL,0,NULL,NULL,0,'pt-br',0,0,NULL,6,1,1,0,'000C'),(14,'admin','admin','2016-12-21 18:33:14.038000','2016-12-21 18:33:14.633000','2016-12-21 18:33:14.023000',NULL,1,0,NULL,'','home.html',0,NULL,0,'',NULL,0,'pt-br',0,0,NULL,7,1,1,0,'000E'),(15,'admin','admin','2016-12-21 18:33:36.485000','2016-12-21 18:33:36.756000','2016-12-21 18:33:36.469000',NULL,0,0,'page_types',NULL,'INHERIT',0,NULL,0,NULL,NULL,0,'pt-br',0,0,NULL,9,1,1,0,'000G'),(16,'script','admin','2016-12-22 18:58:12.840000','2016-12-24 14:31:02.162000','2016-12-24 14:31:01.689000',NULL,1,0,NULL,NULL,'INHERIT',0,NULL,0,NULL,NULL,1,'pt-br',0,0,NULL,18,1,1,0,'000H'),(17,'script','admin','2016-12-22 19:00:14.034000','2016-12-24 14:31:10.500000','2016-12-24 14:31:10.187000',NULL,1,0,NULL,NULL,'INHERIT',0,NULL,0,NULL,NULL,1,'pt-br',0,0,NULL,19,1,1,0,'000J'),(18,'admin','admin','2016-12-24 14:31:01.706000','2016-12-24 14:31:02.021000','2016-12-24 14:31:01.689000',NULL,1,0,NULL,NULL,'INHERIT',0,NULL,0,NULL,NULL,0,'pt-br',0,0,NULL,16,1,1,0,'000I'),(19,'admin','admin','2016-12-24 14:31:10.202000','2016-12-24 14:31:10.383000','2016-12-24 14:31:10.187000',NULL,1,0,NULL,NULL,'INHERIT',0,NULL,0,NULL,NULL,0,'pt-br',0,0,NULL,17,1,1,0,'000K');
/*!40000 ALTER TABLE `cms_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_page_placeholders`
--

DROP TABLE IF EXISTS `cms_page_placeholders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_page_placeholders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `placeholder_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_id` (`page_id`,`placeholder_id`),
  KEY `cms_page_placehold_placeholder_id_73892653_fk_cms_placeholder_id` (`placeholder_id`),
  CONSTRAINT `cms_page_placehold_placeholder_id_73892653_fk_cms_placeholder_id` FOREIGN KEY (`placeholder_id`) REFERENCES `cms_placeholder` (`id`),
  CONSTRAINT `cms_page_placeholders_page_id_2425adb6_fk_cms_page_id` FOREIGN KEY (`page_id`) REFERENCES `cms_page` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_page_placeholders`
--

LOCK TABLES `cms_page_placeholders` WRITE;
/*!40000 ALTER TABLE `cms_page_placeholders` DISABLE KEYS */;
INSERT INTO `cms_page_placeholders` VALUES (1,1,2),(16,1,19),(17,1,20),(18,1,21),(19,1,22),(20,1,23),(21,1,24),(22,1,25),(23,1,26),(26,1,29),(2,2,3),(36,2,39),(37,2,40),(38,2,41),(39,2,42),(40,2,43),(41,2,44),(42,2,45),(43,2,46),(44,2,47),(3,3,6),(4,4,7),(5,5,8),(6,6,9),(7,7,10),(27,7,30),(28,7,31),(29,7,32),(30,7,33),(31,7,34),(32,7,35),(33,7,36),(34,7,37),(35,7,38),(9,9,12),(10,10,13),(45,10,48),(46,10,49),(47,10,50),(48,10,51),(49,10,52),(50,10,53),(51,10,54),(52,10,55),(53,10,56),(11,11,14),(12,12,15),(13,13,16),(14,14,17),(15,15,18),(24,16,27),(25,17,28),(54,18,57),(55,19,58);
/*!40000 ALTER TABLE `cms_page_placeholders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_pagepermission`
--

DROP TABLE IF EXISTS `cms_pagepermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_pagepermission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `can_change` tinyint(1) NOT NULL,
  `can_add` tinyint(1) NOT NULL,
  `can_delete` tinyint(1) NOT NULL,
  `can_change_advanced_settings` tinyint(1) NOT NULL,
  `can_publish` tinyint(1) NOT NULL,
  `can_change_permissions` tinyint(1) NOT NULL,
  `can_move_page` tinyint(1) NOT NULL,
  `can_view` tinyint(1) NOT NULL,
  `grant_on` int(11) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `page_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_pagepermission_group_id_7024afda_fk_auth_group_id` (`group_id`),
  KEY `cms_pagepermission_page_id_4fb6ec65_fk_cms_page_id` (`page_id`),
  KEY `cms_pagepermission_user_id_1a3e8e53_fk_auth_user_id` (`user_id`),
  CONSTRAINT `cms_pagepermission_group_id_7024afda_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `cms_pagepermission_page_id_4fb6ec65_fk_cms_page_id` FOREIGN KEY (`page_id`) REFERENCES `cms_page` (`id`),
  CONSTRAINT `cms_pagepermission_user_id_1a3e8e53_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_pagepermission`
--

LOCK TABLES `cms_pagepermission` WRITE;
/*!40000 ALTER TABLE `cms_pagepermission` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_pagepermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_pageuser`
--

DROP TABLE IF EXISTS `cms_pageuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_pageuser` (
  `user_ptr_id` int(11) NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`user_ptr_id`),
  KEY `cms_pageuser_created_by_id_3190e3ea_fk_auth_user_id` (`created_by_id`),
  CONSTRAINT `cms_pageuser_created_by_id_3190e3ea_fk_auth_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `cms_pageuser_user_ptr_id_6b58ccde_fk_auth_user_id` FOREIGN KEY (`user_ptr_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_pageuser`
--

LOCK TABLES `cms_pageuser` WRITE;
/*!40000 ALTER TABLE `cms_pageuser` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_pageuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_pageusergroup`
--

DROP TABLE IF EXISTS `cms_pageusergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_pageusergroup` (
  `group_ptr_id` int(11) NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`group_ptr_id`),
  KEY `cms_pageusergroup_created_by_id_4fdafe6a_fk_auth_user_id` (`created_by_id`),
  CONSTRAINT `cms_pageusergroup_created_by_id_4fdafe6a_fk_auth_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `cms_pageusergroup_group_ptr_id_61ee8ff1_fk_auth_group_id` FOREIGN KEY (`group_ptr_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_pageusergroup`
--

LOCK TABLES `cms_pageusergroup` WRITE;
/*!40000 ALTER TABLE `cms_pageusergroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_pageusergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_placeholder`
--

DROP TABLE IF EXISTS `cms_placeholder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_placeholder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slot` varchar(255) NOT NULL,
  `default_width` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_placeholder_5e97994e` (`slot`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_placeholder`
--

LOCK TABLES `cms_placeholder` WRITE;
/*!40000 ALTER TABLE `cms_placeholder` DISABLE KEYS */;
INSERT INTO `cms_placeholder` VALUES (1,'clipboard',NULL),(2,'content',NULL),(3,'content',NULL),(4,'Footer',NULL),(5,'Footer',NULL),(6,'content',NULL),(7,'content',NULL),(8,'content',NULL),(9,'content',NULL),(10,'content',NULL),(12,'content',NULL),(13,'content',NULL),(14,'content',NULL),(15,'content',NULL),(16,'content',NULL),(17,'content',NULL),(18,'content',NULL),(19,'carousel',NULL),(20,'service_1',NULL),(21,'services-head',NULL),(22,'service_2',NULL),(23,'service_3',NULL),(24,'service_4',NULL),(25,'service_5',NULL),(26,'service_6',NULL),(27,'content',NULL),(28,'content',NULL),(29,'partners',NULL),(30,'carousel',NULL),(31,'services-head',NULL),(32,'service_1',NULL),(33,'service_2',NULL),(34,'service_3',NULL),(35,'service_4',NULL),(36,'service_5',NULL),(37,'service_6',NULL),(38,'partners',NULL),(39,'carousel',NULL),(40,'services-head',NULL),(41,'service_1',NULL),(42,'service_2',NULL),(43,'service_3',NULL),(44,'service_4',NULL),(45,'service_5',NULL),(46,'service_6',NULL),(47,'partners',NULL),(48,'carousel',NULL),(49,'services-head',NULL),(50,'service_1',NULL),(51,'service_2',NULL),(52,'service_3',NULL),(53,'service_4',NULL),(54,'service_5',NULL),(55,'service_6',NULL),(56,'partners',NULL),(57,'content',NULL),(58,'content',NULL);
/*!40000 ALTER TABLE `cms_placeholder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_placeholderreference`
--

DROP TABLE IF EXISTS `cms_placeholderreference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_placeholderreference` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `placeholder_ref_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `cms_placeholderreference_328d0afc` (`placeholder_ref_id`),
  CONSTRAINT `cms_placeholde_placeholder_ref_id_5d0b7714_fk_cms_placeholder_id` FOREIGN KEY (`placeholder_ref_id`) REFERENCES `cms_placeholder` (`id`),
  CONSTRAINT `cms_placeholderref_cmsplugin_ptr_id_379b411a_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_placeholderreference`
--

LOCK TABLES `cms_placeholderreference` WRITE;
/*!40000 ALTER TABLE `cms_placeholderreference` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_placeholderreference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_staticplaceholder`
--

DROP TABLE IF EXISTS `cms_staticplaceholder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_staticplaceholder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `dirty` tinyint(1) NOT NULL,
  `creation_method` varchar(20) NOT NULL,
  `draft_id` int(11) DEFAULT NULL,
  `public_id` int(11) DEFAULT NULL,
  `site_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cms_staticplaceholder_code_601f1ba7_uniq` (`code`,`site_id`),
  KEY `cms_staticplaceholder_site_id_163af08f_fk_django_site_id` (`site_id`),
  KEY `cms_staticplaceholder_5cb48773` (`draft_id`),
  KEY `cms_staticplaceholder_1ee2744d` (`public_id`),
  CONSTRAINT `cms_staticplaceholder_draft_id_36488820_fk_cms_placeholder_id` FOREIGN KEY (`draft_id`) REFERENCES `cms_placeholder` (`id`),
  CONSTRAINT `cms_staticplaceholder_public_id_510a87f7_fk_cms_placeholder_id` FOREIGN KEY (`public_id`) REFERENCES `cms_placeholder` (`id`),
  CONSTRAINT `cms_staticplaceholder_site_id_163af08f_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_staticplaceholder`
--

LOCK TABLES `cms_staticplaceholder` WRITE;
/*!40000 ALTER TABLE `cms_staticplaceholder` DISABLE KEYS */;
INSERT INTO `cms_staticplaceholder` VALUES (1,'','Footer',0,'template',4,5,NULL);
/*!40000 ALTER TABLE `cms_staticplaceholder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_title`
--

DROP TABLE IF EXISTS `cms_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_title` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(15) NOT NULL,
  `title` varchar(255) NOT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `menu_title` varchar(255) DEFAULT NULL,
  `meta_description` longtext,
  `slug` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `has_url_overwrite` tinyint(1) NOT NULL,
  `redirect` varchar(2048) DEFAULT NULL,
  `creation_date` datetime(6) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `publisher_is_draft` tinyint(1) NOT NULL,
  `publisher_state` smallint(6) NOT NULL,
  `page_id` int(11) NOT NULL,
  `publisher_public_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cms_title_language_507a9d79_uniq` (`language`,`page_id`),
  UNIQUE KEY `publisher_public_id` (`publisher_public_id`),
  KEY `cms_title_page_id_c6c95ee_fk_cms_page_id` (`page_id`),
  KEY `cms_title_8512ae7d` (`language`),
  KEY `cms_title_2dbcba41` (`slug`),
  KEY `cms_title_d6fe1d0b` (`path`),
  KEY `cms_title_1268de9a` (`has_url_overwrite`),
  KEY `cms_title_b7700099` (`publisher_is_draft`),
  KEY `cms_title_f7202fc0` (`publisher_state`),
  CONSTRAINT `cms_title_page_id_c6c95ee_fk_cms_page_id` FOREIGN KEY (`page_id`) REFERENCES `cms_page` (`id`),
  CONSTRAINT `cms_title_publisher_public_id_2b3e4a1d_fk_cms_title_id` FOREIGN KEY (`publisher_public_id`) REFERENCES `cms_title` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_title`
--

LOCK TABLES `cms_title` WRITE;
/*!40000 ALTER TABLE `cms_title` DISABLE KEYS */;
INSERT INTO `cms_title` VALUES (1,'pt-br','Federação Mineira de Sinuca e Bilhar','Federação Mineira de Sinuca e Bilhar','Home','','home','',0,'','2016-12-21 11:50:27.036000',1,1,1,1,2),(2,'pt-br','Home',NULL,NULL,NULL,'home','',0,NULL,'2016-12-21 11:50:27.036000',1,0,1,2,1),(3,'pt-br','Filie-se',NULL,NULL,NULL,'filie-se','filie-se',0,'','2016-12-21 17:56:16.895000',1,1,0,3,10),(4,'pt-br','Regras',NULL,NULL,NULL,'regras','regras',0,NULL,'2016-12-21 17:59:09.621000',1,1,0,4,11),(5,'pt-br','Ranking',NULL,NULL,NULL,'ranking','ranking',0,NULL,'2016-12-21 18:02:02.546000',1,1,0,5,12),(6,'pt-br','Eventos',NULL,NULL,NULL,'eventos','eventos',0,NULL,'2016-12-21 18:02:52.295000',1,1,0,6,13),(7,'pt-br','Parceiros',NULL,NULL,NULL,'parceiros','parceiros',0,'','2016-12-21 18:06:17.385000',1,1,0,7,14),(9,'pt-br','Page Types',NULL,NULL,NULL,'page_types','page_types',0,NULL,'2016-12-21 18:08:23.964000',1,1,0,9,15),(10,'pt-br','Filie-se',NULL,NULL,NULL,'filie-se','filie-se',0,'','2016-12-21 17:56:16.895000',1,0,0,10,3),(11,'pt-br','Regras',NULL,NULL,NULL,'regras','regras',0,NULL,'2016-12-21 17:59:09.621000',1,0,0,11,4),(12,'pt-br','Ranking',NULL,NULL,NULL,'ranking','ranking',0,NULL,'2016-12-21 18:02:02.546000',1,0,0,12,5),(13,'pt-br','Eventos',NULL,NULL,NULL,'eventos','eventos',0,NULL,'2016-12-21 18:02:52.295000',1,0,0,13,6),(14,'pt-br','Parceiros',NULL,NULL,NULL,'parceiros','parceiros',0,'','2016-12-21 18:06:17.385000',1,0,0,14,7),(15,'pt-br','Page Types',NULL,NULL,NULL,'page_types','page_types',0,NULL,'2016-12-21 18:08:23.964000',1,0,0,15,9),(16,'pt-br','Institucional',NULL,NULL,NULL,'institucional','institucional',0,NULL,'2016-12-22 18:58:13.448000',1,1,0,16,18),(17,'pt-br','Notícias',NULL,NULL,NULL,'noticias','noticias',0,NULL,'2016-12-22 19:00:14.373000',1,1,0,17,19),(18,'pt-br','Institucional',NULL,NULL,NULL,'institucional','institucional',0,NULL,'2016-12-22 18:58:13.448000',1,0,0,18,16),(19,'pt-br','Notícias',NULL,NULL,NULL,'noticias','noticias',0,NULL,'2016-12-22 19:00:14.373000',1,0,0,19,17);
/*!40000 ALTER TABLE `cms_title` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_urlconfrevision`
--

DROP TABLE IF EXISTS `cms_urlconfrevision`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_urlconfrevision` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `revision` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_urlconfrevision`
--

LOCK TABLES `cms_urlconfrevision` WRITE;
/*!40000 ALTER TABLE `cms_urlconfrevision` DISABLE KEYS */;
INSERT INTO `cms_urlconfrevision` VALUES (1,'98ca36d8-0549-4da6-9c48-7ff9a0dc8f55');
/*!40000 ALTER TABLE `cms_urlconfrevision` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_usersettings`
--

DROP TABLE IF EXISTS `cms_usersettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_usersettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(10) NOT NULL,
  `clipboard_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `cms_usersettings_clipboard_id_124304f3_fk_cms_placeholder_id` (`clipboard_id`),
  CONSTRAINT `cms_usersettings_clipboard_id_124304f3_fk_cms_placeholder_id` FOREIGN KEY (`clipboard_id`) REFERENCES `cms_placeholder` (`id`),
  CONSTRAINT `cms_usersettings_user_id_28ccc2b3_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_usersettings`
--

LOCK TABLES `cms_usersettings` WRITE;
/*!40000 ALTER TABLE `cms_usersettings` DISABLE KEYS */;
INSERT INTO `cms_usersettings` VALUES (1,'en',1,1);
/*!40000 ALTER TABLE `cms_usersettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsplugin_filer_file_filerfile`
--

DROP TABLE IF EXISTS `cmsplugin_filer_file_filerfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsplugin_filer_file_filerfile` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `target_blank` tinyint(1) NOT NULL,
  `style` varchar(255) NOT NULL,
  `file_id` int(11) DEFAULT NULL,
  `link_attributes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `cmsplugin_filer_file_filerfile_814552b9` (`file_id`),
  CONSTRAINT `cmsplugin_filer_fi_cmsplugin_ptr_id_16b71437_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`),
  CONSTRAINT `cmsplugin_filer_file_filerfile_file_id_7cffe72d_fk_filer_file_id` FOREIGN KEY (`file_id`) REFERENCES `filer_file` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsplugin_filer_file_filerfile`
--

LOCK TABLES `cmsplugin_filer_file_filerfile` WRITE;
/*!40000 ALTER TABLE `cmsplugin_filer_file_filerfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `cmsplugin_filer_file_filerfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsplugin_filer_folder_filerfolder`
--

DROP TABLE IF EXISTS `cmsplugin_filer_folder_filerfolder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsplugin_filer_folder_filerfolder` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `style` varchar(50) NOT NULL,
  `folder_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `cmsplugin_filer_folder_filerfolder_a8a44dbb` (`folder_id`),
  CONSTRAINT `cmsplugin_filer_fo_cmsplugin_ptr_id_51d7603b_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`),
  CONSTRAINT `cmsplugin_filer_folder_fil_folder_id_479ba6a7_fk_filer_folder_id` FOREIGN KEY (`folder_id`) REFERENCES `filer_folder` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsplugin_filer_folder_filerfolder`
--

LOCK TABLES `cmsplugin_filer_folder_filerfolder` WRITE;
/*!40000 ALTER TABLE `cmsplugin_filer_folder_filerfolder` DISABLE KEYS */;
/*!40000 ALTER TABLE `cmsplugin_filer_folder_filerfolder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmsplugin_filer_image_filerimage`
--

DROP TABLE IF EXISTS `cmsplugin_filer_image_filerimage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cmsplugin_filer_image_filerimage` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `style` varchar(50) NOT NULL,
  `caption_text` varchar(255) DEFAULT NULL,
  `image_url` varchar(200) DEFAULT NULL,
  `alt_text` varchar(255) DEFAULT NULL,
  `use_original_image` tinyint(1) NOT NULL,
  `use_autoscale` tinyint(1) NOT NULL,
  `width` int(10) unsigned DEFAULT NULL,
  `height` int(10) unsigned DEFAULT NULL,
  `crop` tinyint(1) NOT NULL,
  `upscale` tinyint(1) NOT NULL,
  `alignment` varchar(10) DEFAULT NULL,
  `free_link` varchar(2000) DEFAULT NULL,
  `original_link` tinyint(1) NOT NULL,
  `description` longtext,
  `target_blank` tinyint(1) NOT NULL,
  `file_link_id` int(11) DEFAULT NULL,
  `image_id` int(11) DEFAULT NULL,
  `page_link_id` int(11) DEFAULT NULL,
  `thumbnail_option_id` int(11),
  `link_attributes` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `cmsplugin_filer_image_filerimage_0fe0fc57` (`file_link_id`),
  KEY `cmsplugin_filer_image_filerimage_f33175e6` (`image_id`),
  KEY `cmsplugin_filer_image_filerimage_d916d256` (`page_link_id`),
  KEY `cmsplugin_filer_image_filerimage_6b85b7b1` (`thumbnail_option_id`),
  CONSTRAINT `cmsplug_thumbnail_option_id_5de3f97b_fk_filer_thumbnailoption_id` FOREIGN KEY (`thumbnail_option_id`) REFERENCES `filer_thumbnailoption` (`id`),
  CONSTRAINT `cmsplugin_filer_im_cmsplugin_ptr_id_5378a28b_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`),
  CONSTRAINT `cmsplugin_filer_ima_image_id_235865ab_fk_filer_image_file_ptr_id` FOREIGN KEY (`image_id`) REFERENCES `filer_image` (`file_ptr_id`),
  CONSTRAINT `cmsplugin_filer_image_fil_file_link_id_4afd23fb_fk_filer_file_id` FOREIGN KEY (`file_link_id`) REFERENCES `filer_file` (`id`),
  CONSTRAINT `cmsplugin_filer_image_filer_page_link_id_334c6db0_fk_cms_page_id` FOREIGN KEY (`page_link_id`) REFERENCES `cms_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmsplugin_filer_image_filerimage`
--

LOCK TABLES `cmsplugin_filer_image_filerimage` WRITE;
/*!40000 ALTER TABLE `cmsplugin_filer_image_filerimage` DISABLE KEYS */;
/*!40000 ALTER TABLE `cmsplugin_filer_image_filerimage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin__content_type_id_5151027a_fk_django_content_type_id` (`content_type_id`),
  KEY `django_admin_log_user_id_1c5f563_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin__content_type_id_5151027a_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_1c5f563_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2016-12-21 11:52:56.477000','1','fmsb.com.br',2,'Changed domain and name.',9,1),(2,'2016-12-21 15:55:11.980000','6','6',3,'',15,1),(3,'2016-12-21 16:03:08.782000','1','1',3,'',15,1),(4,'2016-12-21 18:07:16.443000','7','Parceiros',2,'Changed template and xframe_options.',2,1),(5,'2016-12-21 18:08:43.905000','8','sub parceiros',3,'',2,1),(6,'2016-12-21 18:32:03.278000','1','Home',2,'',2,1),(7,'2016-12-21 18:32:36.158000','3','Filie-se',2,'',2,1),(8,'2016-12-21 18:32:38.922000','4','Regras',2,'',2,1),(9,'2016-12-21 18:32:57.727000','5','Ranking',2,'',2,1),(10,'2016-12-21 18:33:07.051000','6','Eventos',2,'',2,1),(11,'2016-12-21 18:33:14.852000','7','Parceiros',2,'',2,1),(12,'2016-12-21 18:33:37.006000','9','Page Types',2,'',2,1),(13,'2016-12-21 18:50:52.500000','1','Home',2,'',2,1),(14,'2016-12-21 23:04:07.276000','23','23',3,'',15,1),(15,'2016-12-21 23:10:05.864000','1','Home',2,'',2,1),(16,'2016-12-22 00:18:04.206000','1','Home',2,'',2,1),(17,'2016-12-22 00:52:51.740000','1','Home',2,'',2,1),(18,'2016-12-22 00:56:10.154000','1','clipboard',3,'',1,1),(19,'2016-12-22 01:03:28.513000','72','72',3,'',15,1),(20,'2016-12-22 02:20:31.239000','1','clipboard',3,'',1,1),(21,'2016-12-22 02:21:58.514000','85','85',3,'',15,1),(22,'2016-12-22 17:41:23.320000','1','clipboard',3,'',1,1),(23,'2016-12-22 18:41:07.849000','1','clipboard',3,'',1,1),(24,'2016-12-23 16:45:45.010000','1','Home',2,'',2,1),(25,'2016-12-24 02:29:55.062000','3','Filie-se',2,'Changed template and xframe_options.',2,1),(26,'2016-12-24 03:50:26.463000','3','Filie-se',2,'',2,1),(27,'2016-12-24 14:28:55.065000','1','Home',2,'Modificado title e page_title.',2,1),(28,'2016-12-24 14:30:10.762000','1','Federação Mineira de Sinuca e Bilhar',2,'Modificado reverse_id e xframe_options.',2,1),(29,'2016-12-24 14:31:02.335000','16','Institucional',2,'',2,1),(30,'2016-12-24 14:31:10.632000','17','Notícias',2,'',2,1),(31,'2016-12-24 14:32:58.642000','1','Federação Mineira de Sinuca e Bilhar',2,'Changed menu_title.',2,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_3ec8c61c_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (8,'admin','logentry'),(54,'aldryn_bootstrap3','boostrap3alertplugin'),(50,'aldryn_bootstrap3','boostrap3blockquoteplugin'),(49,'aldryn_bootstrap3','boostrap3buttonplugin'),(51,'aldryn_bootstrap3','boostrap3iconplugin'),(55,'aldryn_bootstrap3','boostrap3imageplugin'),(52,'aldryn_bootstrap3','boostrap3labelplugin'),(60,'aldryn_bootstrap3','boostrap3panelbodyplugin'),(61,'aldryn_bootstrap3','boostrap3panelfooterplugin'),(59,'aldryn_bootstrap3','boostrap3panelheadingplugin'),(58,'aldryn_bootstrap3','boostrap3panelplugin'),(56,'aldryn_bootstrap3','boostrap3spacerplugin'),(53,'aldryn_bootstrap3','boostrap3wellplugin'),(65,'aldryn_bootstrap3','bootstrap3accordionitemplugin'),(64,'aldryn_bootstrap3','bootstrap3accordionplugin'),(68,'aldryn_bootstrap3','bootstrap3carouselplugin'),(70,'aldryn_bootstrap3','bootstrap3carouselslidefolderplugin'),(69,'aldryn_bootstrap3','bootstrap3carouselslideplugin'),(63,'aldryn_bootstrap3','bootstrap3columnplugin'),(57,'aldryn_bootstrap3','bootstrap3fileplugin'),(67,'aldryn_bootstrap3','bootstrap3listgroupitemplugin'),(66,'aldryn_bootstrap3','bootstrap3listgroupplugin'),(62,'aldryn_bootstrap3','bootstrap3rowplugin'),(48,'aldryn_style','style'),(4,'auth','group'),(3,'auth','permission'),(5,'auth','user'),(19,'cms','aliaspluginmodel'),(15,'cms','cmsplugin'),(11,'cms','globalpagepermission'),(2,'cms','page'),(12,'cms','pagepermission'),(13,'cms','pageuser'),(14,'cms','pageusergroup'),(1,'cms','placeholder'),(17,'cms','placeholderreference'),(18,'cms','staticplaceholder'),(16,'cms','title'),(20,'cms','urlconfrevision'),(10,'cms','usersettings'),(36,'cmsplugin_filer_file','filerfile'),(37,'cmsplugin_filer_folder','filerfolder'),(38,'cmsplugin_filer_image','filerimage'),(6,'contenttypes','contenttype'),(34,'djangocms_column','column'),(33,'djangocms_column','multicolumns'),(42,'djangocms_googlemap','googlemap'),(43,'djangocms_googlemap','googlemapmarker'),(44,'djangocms_googlemap','googlemaproute'),(35,'djangocms_link','link'),(40,'djangocms_snippet','snippet'),(41,'djangocms_snippet','snippetptr'),(39,'djangocms_style','style'),(22,'djangocms_text_ckeditor','text'),(45,'djangocms_video','videoplayer'),(46,'djangocms_video','videosource'),(47,'djangocms_video','videotrack'),(30,'easy_thumbnails','source'),(31,'easy_thumbnails','thumbnail'),(32,'easy_thumbnails','thumbnaildimensions'),(26,'filer','clipboard'),(27,'filer','clipboarditem'),(25,'filer','file'),(23,'filer','folder'),(24,'filer','folderpermission'),(28,'filer','image'),(29,'filer','thumbnailoption'),(21,'menus','cachekey'),(7,'sessions','session'),(9,'sites','site');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2016-12-20 23:29:22.958000'),(2,'auth','0001_initial','2016-12-20 23:29:28.255000'),(3,'admin','0001_initial','2016-12-20 23:29:29.764000'),(4,'contenttypes','0002_remove_content_type_name','2016-12-20 23:29:30.778000'),(5,'auth','0002_alter_permission_name_max_length','2016-12-20 23:29:31.418000'),(6,'auth','0003_alter_user_email_max_length','2016-12-20 23:29:31.972000'),(7,'auth','0004_alter_user_username_opts','2016-12-20 23:29:32.021000'),(8,'auth','0005_alter_user_last_login_null','2016-12-20 23:29:32.540000'),(9,'auth','0006_require_contenttypes_0002','2016-12-20 23:29:32.558000'),(10,'sites','0001_initial','2016-12-20 23:29:32.807000'),(11,'cms','0001_initial','2016-12-20 23:29:46.474000'),(12,'cms','0002_auto_20140816_1918','2016-12-20 23:30:03.604000'),(13,'cms','0003_auto_20140926_2347','2016-12-20 23:30:04.247000'),(14,'cms','0004_auto_20140924_1038','2016-12-20 23:30:12.450000'),(15,'cms','0005_auto_20140924_1039','2016-12-20 23:30:12.565000'),(16,'cms','0006_auto_20140924_1110','2016-12-20 23:30:20.484000'),(17,'cms','0007_auto_20141028_1559','2016-12-20 23:30:20.882000'),(18,'cms','0008_auto_20150208_2149','2016-12-20 23:30:22.011000'),(19,'cms','0008_auto_20150121_0059','2016-12-20 23:30:22.702000'),(20,'cms','0009_merge','2016-12-20 23:30:22.732000'),(21,'cms','0010_migrate_use_structure','2016-12-20 23:30:23.686000'),(22,'cms','0011_auto_20150419_1006','2016-12-20 23:30:26.180000'),(23,'cms','0012_auto_20150607_2207','2016-12-20 23:30:28.561000'),(24,'cms','0013_urlconfrevision','2016-12-20 23:30:28.870000'),(25,'cms','0014_auto_20160404_1908','2016-12-20 23:30:28.940000'),(26,'cms','0015_auto_20160421_0000','2016-12-20 23:30:29.997000'),(27,'cms','0016_auto_20160608_1535','2016-12-20 23:30:31.768000'),(28,'filer','0001_initial','2016-12-20 23:30:46.550000'),(29,'cmsplugin_filer_file','0001_initial','2016-12-20 23:30:48.030000'),(30,'cmsplugin_filer_file','0002_auto_20160112_1617','2016-12-20 23:30:49.259000'),(31,'cmsplugin_filer_file','0003_filerfile_link_attributes','2016-12-20 23:30:49.744000'),(32,'cmsplugin_filer_file','0004_auto_20160705_1334','2016-12-20 23:30:49.935000'),(33,'cmsplugin_filer_file','0005_auto_20160713_1853','2016-12-20 23:30:50.717000'),(34,'cmsplugin_filer_folder','0001_initial','2016-12-20 23:30:52.846000'),(35,'cmsplugin_filer_folder','0002_auto_20160113_1318','2016-12-20 23:30:54.039000'),(36,'cmsplugin_filer_folder','0003_auto_20160713_1853','2016-12-20 23:30:54.861000'),(37,'filer','0002_auto_20150606_2003','2016-12-20 23:30:55.837000'),(38,'filer','0003_thumbnailoption','2016-12-20 23:30:56.140000'),(39,'cmsplugin_filer_image','0001_initial','2016-12-20 23:31:04.449000'),(40,'cmsplugin_filer_image','0002_auto_20160108_1708','2016-12-20 23:31:06.549000'),(41,'cmsplugin_filer_image','0003_mv_thumbnail_option_to_filer_20160119_1720','2016-12-20 23:31:06.591000'),(42,'cmsplugin_filer_image','0004_auto_20160120_0950','2016-12-20 23:31:07.661000'),(43,'cmsplugin_filer_image','0005_auto_20160224_1457','2016-12-20 23:31:08.904000'),(44,'cmsplugin_filer_image','0006_auto_20160427_1438','2016-12-20 23:31:09.126000'),(45,'cmsplugin_filer_image','0007_filerimage_link_attributes','2016-12-20 23:31:09.899000'),(46,'cmsplugin_filer_image','0008_auto_20160705_1334','2016-12-20 23:31:10.114000'),(47,'cmsplugin_filer_image','0009_auto_20160713_1853','2016-12-20 23:31:11.835000'),(48,'djangocms_column','0001_initial','2016-12-20 23:31:13.821000'),(49,'djangocms_column','0002_auto_20160915_0818','2016-12-20 23:31:15.413000'),(50,'djangocms_googlemap','0001_initial','2016-12-20 23:31:16.483000'),(51,'djangocms_googlemap','0002_auto_20160622_1031','2016-12-20 23:31:18.307000'),(52,'djangocms_googlemap','0003_auto_20160825_1829','2016-12-20 23:31:18.570000'),(53,'djangocms_googlemap','0004_adapted_fields','2016-12-20 23:31:34.447000'),(54,'djangocms_googlemap','0005_create_nested_plugins','2016-12-20 23:31:34.521000'),(55,'djangocms_googlemap','0006_remove_fields','2016-12-20 23:31:39.235000'),(56,'djangocms_googlemap','0007_reset_null_values','2016-12-20 23:31:39.293000'),(57,'djangocms_googlemap','0008_removed_null_fields','2016-12-20 23:31:40.018000'),(58,'djangocms_link','0001_initial','2016-12-20 23:31:41.492000'),(59,'djangocms_link','0002_auto_20140929_1705','2016-12-20 23:31:41.794000'),(60,'djangocms_link','0003_auto_20150212_1310','2016-12-20 23:31:42.074000'),(61,'djangocms_link','0004_auto_20150708_1133','2016-12-20 23:31:43.077000'),(62,'djangocms_link','0005_auto_20151003_1710','2016-12-20 23:31:43.768000'),(63,'djangocms_link','0006_remove_related_name_for_cmsplugin_ptr','2016-12-20 23:31:45.329000'),(64,'djangocms_link','0007_set_related_name_for_cmsplugin_ptr','2016-12-20 23:31:46.072000'),(65,'djangocms_link','0008_link_attributes','2016-12-20 23:31:46.924000'),(66,'djangocms_link','0009_auto_20160705_1344','2016-12-20 23:31:47.197000'),(67,'djangocms_link','0010_adapted_fields','2016-12-20 23:31:56.871000'),(68,'djangocms_link','0011_fixed_null_values','2016-12-20 23:31:57.106000'),(69,'djangocms_link','0012_removed_null','2016-12-20 23:32:01.488000'),(70,'djangocms_link','0013_fix_hostname','2016-12-20 23:32:01.754000'),(71,'djangocms_snippet','0001_initial','2016-12-20 23:32:03.867000'),(72,'djangocms_snippet','0002_snippet_slug','2016-12-20 23:32:04.828000'),(73,'djangocms_snippet','0003_auto_data_fill_slug','2016-12-20 23:32:04.900000'),(74,'djangocms_snippet','0004_auto_alter_slug_unique','2016-12-20 23:32:05.370000'),(75,'djangocms_snippet','0005_set_related_name_for_cmsplugin_ptr','2016-12-20 23:32:06.200000'),(76,'djangocms_snippet','0006_auto_20160831_0729','2016-12-20 23:32:08.597000'),(77,'djangocms_snippet','0007_auto_alter_template_helptext','2016-12-20 23:32:09.575000'),(78,'djangocms_style','0001_initial','2016-12-20 23:32:10.548000'),(79,'djangocms_style','0002_set_related_name_for_cmsplugin_ptr','2016-12-20 23:32:11.374000'),(80,'djangocms_style','0003_adapted_fields','2016-12-20 23:32:18.482000'),(81,'djangocms_style','0004_use_positive_small_integer_field','2016-12-20 23:32:26.011000'),(82,'djangocms_style','0005_reset_null_values','2016-12-20 23:32:26.065000'),(85,'djangocms_text_ckeditor','0001_initial','2016-12-20 23:32:28.788000'),(86,'djangocms_text_ckeditor','0002_remove_related_name_for_cmsplugin_ptr','2016-12-20 23:32:29.502000'),(87,'djangocms_text_ckeditor','0003_set_related_name_for_cmsplugin_ptr','2016-12-20 23:32:30.279000'),(88,'djangocms_text_ckeditor','0004_auto_20160706_1339','2016-12-20 23:32:30.334000'),(89,'filer','0004_auto_20160328_1434','2016-12-20 23:32:30.957000'),(90,'filer','0005_auto_20160623_1425','2016-12-20 23:32:33.991000'),(91,'filer','0006_auto_20160623_1627','2016-12-20 23:32:34.879000'),(92,'djangocms_video','0001_initial','2016-12-20 23:32:35.907000'),(93,'djangocms_video','0002_set_related_name_for_cmsplugin_ptr','2016-12-20 23:32:36.874000'),(94,'djangocms_video','0003_field_adaptions','2016-12-20 23:32:42.478000'),(95,'djangocms_video','0004_move_to_attributes','2016-12-20 23:32:53.196000'),(96,'djangocms_video','0005_migrate_to_filer','2016-12-20 23:32:53.337000'),(97,'djangocms_video','0006_field_adaptions','2016-12-20 23:32:58.639000'),(98,'djangocms_video','0007_create_nested_plugin','2016-12-20 23:32:59.338000'),(99,'djangocms_video','0008_reset_null_values','2016-12-20 23:32:59.393000'),(100,'djangocms_video','0009_removed_null_values','2016-12-20 23:33:00.302000'),(101,'easy_thumbnails','0001_initial','2016-12-20 23:33:02.955000'),(102,'easy_thumbnails','0002_thumbnaildimensions','2016-12-20 23:33:03.739000'),(103,'menus','0001_initial','2016-12-20 23:33:04.093000'),(104,'sessions','0001_initial','2016-12-20 23:33:04.893000'),(105,'aldryn_style','0001_initial','2016-12-21 15:25:40.541000'),(106,'aldryn_style','0002_auto_20150622_1606','2016-12-21 15:25:40.880000'),(107,'aldryn_style','0003_auto_20161221_1325','2016-12-21 15:25:41.176000'),(108,'aldryn_bootstrap3','0001_initial','2016-12-21 15:33:58.907000'),(109,'aldryn_bootstrap3','0002_bootstrap3fileplugin','2016-12-21 15:34:00.895000'),(110,'aldryn_bootstrap3','0003_auto_20151113_1604','2016-12-21 15:34:04.702000'),(111,'aldryn_bootstrap3','0004_auto_20151211_1333','2016-12-21 15:34:10.198000'),(112,'aldryn_bootstrap3','0005_boostrap3imageplugin_use_original_image','2016-12-21 15:34:11.166000'),(113,'aldryn_bootstrap3','0006_auto_20160615_1740','2016-12-21 15:34:12.751000'),(114,'aldryn_bootstrap3','0007_auto_20160705_1155','2016-12-21 15:34:13.579000'),(115,'aldryn_bootstrap3','0008_auto_20160820_2332','2016-12-21 15:34:21.615000');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('65ms53l8n9maldeu8n7yhhh46mudiaae','NGUwZDc5OGM3NzdiODIzMjQ3YWZjOGFkY2Y4YTNhNTdiODA4OTQ5MTp7ImNtc19hZG1pbl9zaXRlIjoxLCJfYXV0aF91c2VyX2lkIjoiMSIsImNtc190b29sYmFyX2Rpc2FibGVkIjpmYWxzZSwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJjbXNfZWRpdCI6dHJ1ZSwiX2F1dGhfdXNlcl9oYXNoIjoiNzE3MmQ2YWIzODAzMTE2NzZhM2FjMjU3OWVkOWVjYjQzMDJkMmMwOCJ9','2017-01-07 14:33:00.277000');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_site`
--

DROP TABLE IF EXISTS `django_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_site`
--

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` VALUES (1,'fmsb.com.br','FMSB');
/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djangocms_column_column`
--

DROP TABLE IF EXISTS `djangocms_column_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djangocms_column_column` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `width` varchar(50) NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `djangocms_column_c_cmsplugin_ptr_id_5f96ba87_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djangocms_column_column`
--

LOCK TABLES `djangocms_column_column` WRITE;
/*!40000 ALTER TABLE `djangocms_column_column` DISABLE KEYS */;
/*!40000 ALTER TABLE `djangocms_column_column` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djangocms_column_multicolumns`
--

DROP TABLE IF EXISTS `djangocms_column_multicolumns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djangocms_column_multicolumns` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `djangocms_column_m_cmsplugin_ptr_id_134360e9_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djangocms_column_multicolumns`
--

LOCK TABLES `djangocms_column_multicolumns` WRITE;
/*!40000 ALTER TABLE `djangocms_column_multicolumns` DISABLE KEYS */;
/*!40000 ALTER TABLE `djangocms_column_multicolumns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djangocms_googlemap_googlemap`
--

DROP TABLE IF EXISTS `djangocms_googlemap_googlemap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djangocms_googlemap_googlemap` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `zoom` smallint(5) unsigned NOT NULL,
  `lat` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `width` varchar(6) NOT NULL,
  `height` varchar(6) NOT NULL,
  `scrollwheel` tinyint(1) NOT NULL,
  `double_click_zoom` tinyint(1) NOT NULL,
  `draggable` tinyint(1) NOT NULL,
  `keyboard_shortcuts` tinyint(1) NOT NULL,
  `pan_control` tinyint(1) NOT NULL,
  `zoom_control` tinyint(1) NOT NULL,
  `street_view_control` tinyint(1) NOT NULL,
  `style` longtext NOT NULL,
  `fullscreen_control` tinyint(1) NOT NULL,
  `map_type_control` varchar(255) NOT NULL,
  `rotate_control` tinyint(1) NOT NULL,
  `scale_control` tinyint(1) NOT NULL,
  `template` varchar(255) NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `djangocms_googlema_cmsplugin_ptr_id_5b2bda43_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djangocms_googlemap_googlemap`
--

LOCK TABLES `djangocms_googlemap_googlemap` WRITE;
/*!40000 ALTER TABLE `djangocms_googlemap_googlemap` DISABLE KEYS */;
/*!40000 ALTER TABLE `djangocms_googlemap_googlemap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djangocms_googlemap_googlemapmarker`
--

DROP TABLE IF EXISTS `djangocms_googlemap_googlemapmarker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djangocms_googlemap_googlemapmarker` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `lat` decimal(10,6) DEFAULT NULL,
  `lng` decimal(10,6) DEFAULT NULL,
  `show_content` tinyint(1) NOT NULL,
  `info_content` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `djangocms_googlema_cmsplugin_ptr_id_4b513ceb_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djangocms_googlemap_googlemapmarker`
--

LOCK TABLES `djangocms_googlemap_googlemapmarker` WRITE;
/*!40000 ALTER TABLE `djangocms_googlemap_googlemapmarker` DISABLE KEYS */;
/*!40000 ALTER TABLE `djangocms_googlemap_googlemapmarker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djangocms_googlemap_googlemaproute`
--

DROP TABLE IF EXISTS `djangocms_googlemap_googlemaproute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djangocms_googlemap_googlemaproute` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `origin` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `travel_mode` varchar(255) NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `djangocms_googlema_cmsplugin_ptr_id_19f24a73_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djangocms_googlemap_googlemaproute`
--

LOCK TABLES `djangocms_googlemap_googlemaproute` WRITE;
/*!40000 ALTER TABLE `djangocms_googlemap_googlemaproute` DISABLE KEYS */;
/*!40000 ALTER TABLE `djangocms_googlemap_googlemaproute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djangocms_link_link`
--

DROP TABLE IF EXISTS `djangocms_link_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djangocms_link_link` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `external_link` varchar(2040) NOT NULL,
  `anchor` varchar(255) NOT NULL,
  `mailto` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `target` varchar(255) NOT NULL,
  `internal_link_id` int(11) DEFAULT NULL,
  `attributes` longtext NOT NULL,
  `template` varchar(255) NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `djangocms_link_link_internal_link_id_5a81a34_fk_cms_page_id` (`internal_link_id`),
  CONSTRAINT `djangocms_link_lin_cmsplugin_ptr_id_2b2c5a7d_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`),
  CONSTRAINT `djangocms_link_link_internal_link_id_5a81a34_fk_cms_page_id` FOREIGN KEY (`internal_link_id`) REFERENCES `cms_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djangocms_link_link`
--

LOCK TABLES `djangocms_link_link` WRITE;
/*!40000 ALTER TABLE `djangocms_link_link` DISABLE KEYS */;
INSERT INTO `djangocms_link_link` VALUES (149,'','','','','','',4,'{}','default'),(150,'','','','','','',4,'{}','default'),(153,'','','','','','',3,'{}','default'),(156,'','','','','','',6,'{}','default'),(159,'','','','','','',5,'{}','default'),(162,'','','','','','',17,'{}','default'),(165,'','','','','','',7,'{}','default'),(197,'','','','','','',4,'{}','default'),(201,'','','','','','',3,'{}','default'),(204,'','','','','','',6,'{}','default'),(207,'','','','','','',5,'{}','default'),(210,'','','','','','',17,'{}','default'),(213,'','','','','','',7,'{}','default');
/*!40000 ALTER TABLE `djangocms_link_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djangocms_snippet_snippet`
--

DROP TABLE IF EXISTS `djangocms_snippet_snippet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djangocms_snippet_snippet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `html` longtext NOT NULL,
  `template` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `djangocms_snippet_snippet_slug_2f9733ed_uniq` (`slug`),
  KEY `djangocms_snippet_snippet_2dbcba41` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djangocms_snippet_snippet`
--

LOCK TABLES `djangocms_snippet_snippet` WRITE;
/*!40000 ALTER TABLE `djangocms_snippet_snippet` DISABLE KEYS */;
/*!40000 ALTER TABLE `djangocms_snippet_snippet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djangocms_snippet_snippetptr`
--

DROP TABLE IF EXISTS `djangocms_snippet_snippetptr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djangocms_snippet_snippetptr` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `snippet_id` int(11) NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `djangocms_sn_snippet_id_28481798_fk_djangocms_snippet_snippet_id` (`snippet_id`),
  CONSTRAINT `djangocms_sn_snippet_id_28481798_fk_djangocms_snippet_snippet_id` FOREIGN KEY (`snippet_id`) REFERENCES `djangocms_snippet_snippet` (`id`),
  CONSTRAINT `djangocms_snippet__cmsplugin_ptr_id_32b1b800_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djangocms_snippet_snippetptr`
--

LOCK TABLES `djangocms_snippet_snippetptr` WRITE;
/*!40000 ALTER TABLE `djangocms_snippet_snippetptr` DISABLE KEYS */;
/*!40000 ALTER TABLE `djangocms_snippet_snippetptr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djangocms_style_style`
--

DROP TABLE IF EXISTS `djangocms_style_style`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djangocms_style_style` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `class_name` varchar(50) DEFAULT NULL,
  `tag_type` varchar(255) NOT NULL,
  `padding_left` smallint(5) unsigned DEFAULT NULL,
  `padding_right` smallint(5) unsigned DEFAULT NULL,
  `padding_top` smallint(5) unsigned DEFAULT NULL,
  `padding_bottom` smallint(5) unsigned DEFAULT NULL,
  `margin_left` smallint(5) unsigned DEFAULT NULL,
  `margin_right` smallint(5) unsigned DEFAULT NULL,
  `margin_top` smallint(5) unsigned DEFAULT NULL,
  `margin_bottom` smallint(5) unsigned DEFAULT NULL,
  `additional_classes` varchar(255) NOT NULL,
  `attributes` longtext NOT NULL,
  `id_name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `djangocms_style_sty_cmsplugin_ptr_id_f7e4cf9_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djangocms_style_style`
--

LOCK TABLES `djangocms_style_style` WRITE;
/*!40000 ALTER TABLE `djangocms_style_style` DISABLE KEYS */;
/*!40000 ALTER TABLE `djangocms_style_style` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djangocms_text_ckeditor_text`
--

DROP TABLE IF EXISTS `djangocms_text_ckeditor_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djangocms_text_ckeditor_text` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `body` longtext NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  CONSTRAINT `djangocms_text_cke_cmsplugin_ptr_id_2c75ca40_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djangocms_text_ckeditor_text`
--

LOCK TABLES `djangocms_text_ckeditor_text` WRITE;
/*!40000 ALTER TABLE `djangocms_text_ckeditor_text` DISABLE KEYS */;
INSERT INTO `djangocms_text_ckeditor_text` VALUES (5,'© 2016 Federação Mineira de Sinuca e Bilhar. Todos direitos reservados.\n'),(16,'© 2016 Federação Mineira de Sinuca e Bilhar. Todos direitos reservados.\n'),(126,'<h2 class=\"animation animated-item-1\">Nova diretoria assume federação</h2>\n\n<h3 class=\"animation animated-item-2\">Após eleição no meio de 2016, nova diretoria assume com compromisso de renovar o esporte no estado com novas propostas e ações.</h3>\n'),(135,'<h2 class=\"animation animated-item-1\">Faça sua filiação!</h2>\n\n<h3 class=\"animation animated-item-2\">O primeiro passo para a filiação é simples e rápido, acesse o formulário de cadastro e registre-se no site da federação.</h3>\n'),(144,'<h2 class=\"animation animated-item-1\">Copa FECEMG 2016</h2>\n\n<h3 class=\"animation animated-item-2\">Veja os resultados dos clubes, fotos  e performance dos atletas na edição de 2016.</h3>\n'),(147,'<h2>Regras</h2>\n\n<h3>Regras dos jogos mais praticados da sinuca e bilhar além de outros jogos menos conhecidos.</h3>\n'),(148,'<h1>Apoio ao Jodagor</h1>\n\n<p class=\"lead\">A <b>FMSB</b> tem como meta aprimorar o esporte no estado dando suporte e apoio aos jogadores. No site você encontrará diversos materiais, serviços e informações que irá lhe ajudar na prática do esporte.</p>\n'),(151,'<h2>Regras</h2>\n\n<h3>Regras dos jogos mais praticados da sinuca e bilhar além de outros jogos menos conhecidos.</h3>\n'),(154,'<h2>Filiação</h2>\n\n<h3>Torne-se um atleta credenciado e usufrua dos benefícios e serviços da federação.</h3>\n'),(157,'<h2>Torneios</h2>\n\n<h3>Informações sobre os torneios realizados pela federação, datas, prêmios, categorias e mais.</h3>\n'),(160,'<h2>Ranking</h2>\n\n<h3>Entenda como funciona e saiba quais os melhores atletas e todas categorias.</h3>\n'),(163,'<h2>Notícias</h2>\n\n<h3>Fique por dentro de todas as novidades da sinuca no estado e no mundo.</h3>\n'),(166,'<h2>Parceiros</h2>\n\n<h3>Patrocinadores e apoiadores que possibilitam o trabalho da federação.</h3>\n'),(168,'<h2>Nossos Parceiros</h2>\n\n<p class=\"lead\">Estas são algumas das empresas que apoiam o esporte no estado. Sem o apoio e patrocínio delas o trabalho da federação não teria a excelência demandada para a promoção de torneios e demais serviços.</p>\n'),(177,'<h2 class=\"animation animated-item-1\">Nova diretoria assume federação</h2>\n\n<h3 class=\"animation animated-item-2\">Após eleição no meio de 2016, nova diretoria assume com compromisso de renovar o esporte no estado com novas propostas e ações.</h3>\n'),(186,'<h2 class=\"animation animated-item-1\">Faça sua filiação!</h2>\n\n<h3 class=\"animation animated-item-2\">O primeiro passo para a filiação é simples e rápido, acesse o formulário de cadastro e registre-se no site da federação.</h3>\n'),(195,'<h2 class=\"animation animated-item-1\">Copa FECEMG 2016</h2>\n\n<h3 class=\"animation animated-item-2\">Veja os resultados dos clubes, fotos  e performance dos atletas na edição de 2016.</h3>\n'),(198,'<h2>Regras</h2>\n\n<h3>Regras dos jogos mais praticados da sinuca e bilhar além de outros jogos menos conhecidos.</h3>\n'),(200,'<h1>Apoio ao Jodagor</h1>\n\n<p class=\"lead\">A <b>FMSB</b> tem como meta aprimorar o esporte no estado dando suporte e apoio aos jogadores. No site você encontrará diversos materiais, serviços e informações que irá lhe ajudar na prática do esporte.</p>\n'),(202,'<h2>Filiação</h2>\n\n<h3>Torne-se um atleta credenciado e usufrua dos benefícios e serviços da federação.</h3>\n'),(205,'<h2>Torneios</h2>\n\n<h3>Informações sobre os torneios realizados pela federação, datas, prêmios, categorias e mais.</h3>\n'),(208,'<h2>Ranking</h2>\n\n<h3>Entenda como funciona e saiba quais os melhores atletas e todas categorias.</h3>\n'),(211,'<h2>Notícias</h2>\n\n<h3>Fique por dentro de todas as novidades da sinuca no estado e no mundo.</h3>\n'),(214,'<h2>Parceiros</h2>\n\n<h3>Patrocinadores e apoiadores que possibilitam o trabalho da federação.</h3>\n'),(216,'<h2>Nossos Parceiros</h2>\n\n<p class=\"lead\">Estas são algumas das empresas que apoiam o esporte no estado. Sem o apoio e patrocínio delas o trabalho da federação não teria a excelência demandada para a promoção de torneios e demais serviços.</p>\n');
/*!40000 ALTER TABLE `djangocms_text_ckeditor_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djangocms_video_videoplayer`
--

DROP TABLE IF EXISTS `djangocms_video_videoplayer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djangocms_video_videoplayer` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `embed_link` varchar(255) NOT NULL,
  `poster_id` int(11),
  `attributes` longtext NOT NULL,
  `label` varchar(255) NOT NULL,
  `template` varchar(255) NOT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `djangocms_video_videoplayer_9b86e5fe` (`poster_id`),
  CONSTRAINT `djangocms_video_vi_cmsplugin_ptr_id_7c7f2de2_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`),
  CONSTRAINT `djangocms_video_vi_poster_id_4126fb1b_fk_filer_image_file_ptr_id` FOREIGN KEY (`poster_id`) REFERENCES `filer_image` (`file_ptr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djangocms_video_videoplayer`
--

LOCK TABLES `djangocms_video_videoplayer` WRITE;
/*!40000 ALTER TABLE `djangocms_video_videoplayer` DISABLE KEYS */;
/*!40000 ALTER TABLE `djangocms_video_videoplayer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djangocms_video_videosource`
--

DROP TABLE IF EXISTS `djangocms_video_videosource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djangocms_video_videosource` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `text_title` varchar(255) NOT NULL,
  `text_description` longtext NOT NULL,
  `attributes` longtext NOT NULL,
  `source_file_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `djangocms_video_videosource_01490fd0` (`source_file_id`),
  CONSTRAINT `djangocms_video_vid_cmsplugin_ptr_id_ee9a53a_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`),
  CONSTRAINT `djangocms_video_videoso_source_file_id_71700817_fk_filer_file_id` FOREIGN KEY (`source_file_id`) REFERENCES `filer_file` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djangocms_video_videosource`
--

LOCK TABLES `djangocms_video_videosource` WRITE;
/*!40000 ALTER TABLE `djangocms_video_videosource` DISABLE KEYS */;
/*!40000 ALTER TABLE `djangocms_video_videosource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djangocms_video_videotrack`
--

DROP TABLE IF EXISTS `djangocms_video_videotrack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djangocms_video_videotrack` (
  `cmsplugin_ptr_id` int(11) NOT NULL,
  `kind` varchar(255) NOT NULL,
  `srclang` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `attributes` longtext NOT NULL,
  `src_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`cmsplugin_ptr_id`),
  KEY `djangocms_video_videotrack_3166800b` (`src_id`),
  CONSTRAINT `djangocms_video_vid_cmsplugin_ptr_id_1d5f6fb_fk_cms_cmsplugin_id` FOREIGN KEY (`cmsplugin_ptr_id`) REFERENCES `cms_cmsplugin` (`id`),
  CONSTRAINT `djangocms_video_videotrack_src_id_49b76fe4_fk_filer_file_id` FOREIGN KEY (`src_id`) REFERENCES `filer_file` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djangocms_video_videotrack`
--

LOCK TABLES `djangocms_video_videotrack` WRITE;
/*!40000 ALTER TABLE `djangocms_video_videotrack` DISABLE KEYS */;
/*!40000 ALTER TABLE `djangocms_video_videotrack` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `easy_thumbnails_source`
--

DROP TABLE IF EXISTS `easy_thumbnails_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `easy_thumbnails_source` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `storage_hash` varchar(40) NOT NULL,
  `name` varchar(255) NOT NULL,
  `modified` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `easy_thumbnails_source_storage_hash_3e1b0d13_uniq` (`storage_hash`,`name`),
  KEY `easy_thumbnails_source_b454e115` (`storage_hash`),
  KEY `easy_thumbnails_source_b068931c` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `easy_thumbnails_source`
--

LOCK TABLES `easy_thumbnails_source` WRITE;
/*!40000 ALTER TABLE `easy_thumbnails_source` DISABLE KEYS */;
INSERT INTO `easy_thumbnails_source` VALUES (1,'f9bde26a1556cd667f742bd34ec7c55e','filer_public/83/48/8348387a-2122-42cc-896a-9041b8ec1d6d/billiards-282415.jpg','2016-12-21 20:44:46.238000'),(2,'f9bde26a1556cd667f742bd34ec7c55e','filer_public/09/fc/09fca868-4484-4a24-93b9-fb674eb892fa/pool-216416.jpg','2016-12-21 20:44:48.888000'),(3,'f9bde26a1556cd667f742bd34ec7c55e','filer_public/45/58/4558d640-2d7c-405a-8063-66d13c5229fa/pool-table-1331037.jpg','2016-12-21 20:44:51.707000'),(4,'f9bde26a1556cd667f742bd34ec7c55e','filer_public/e4/fd/e4fd95da-52fb-45b3-a0d0-3a47dab3af38/table-386824.jpg','2016-12-21 20:44:52.248000');
/*!40000 ALTER TABLE `easy_thumbnails_source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `easy_thumbnails_thumbnail`
--

DROP TABLE IF EXISTS `easy_thumbnails_thumbnail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `easy_thumbnails_thumbnail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `storage_hash` varchar(40) NOT NULL,
  `name` varchar(255) NOT NULL,
  `modified` datetime(6) NOT NULL,
  `source_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `easy_thumbnails_thumbnail_storage_hash_7ef9fce_uniq` (`storage_hash`,`name`,`source_id`),
  KEY `easy_thumbnails__source_id_7106e1b7_fk_easy_thumbnails_source_id` (`source_id`),
  KEY `easy_thumbnails_thumbnail_b454e115` (`storage_hash`),
  KEY `easy_thumbnails_thumbnail_b068931c` (`name`),
  CONSTRAINT `easy_thumbnails__source_id_7106e1b7_fk_easy_thumbnails_source_id` FOREIGN KEY (`source_id`) REFERENCES `easy_thumbnails_source` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `easy_thumbnails_thumbnail`
--

LOCK TABLES `easy_thumbnails_thumbnail` WRITE;
/*!40000 ALTER TABLE `easy_thumbnails_thumbnail` DISABLE KEYS */;
INSERT INTO `easy_thumbnails_thumbnail` VALUES (1,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/83/48/8348387a-2122-42cc-896a-9041b8ec1d6d\\billiards-282415.jpg__32x32_q85_crop_subsampling-2_upscale.jpg','2016-12-21 17:48:16.972000',1),(2,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/83/48/8348387a-2122-42cc-896a-9041b8ec1d6d\\billiards-282415.jpg__64x64_q85_crop_subsampling-2_upscale.jpg','2016-12-21 17:48:17.314000',1),(3,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/83/48/8348387a-2122-42cc-896a-9041b8ec1d6d\\billiards-282415.jpg__48x48_q85_crop_subsampling-2_upscale.jpg','2016-12-21 17:48:17.611000',1),(4,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/83/48/8348387a-2122-42cc-896a-9041b8ec1d6d\\billiards-282415.jpg__16x16_q85_crop_subsampling-2_upscale.jpg','2016-12-21 17:48:17.818000',1),(5,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/83/48/8348387a-2122-42cc-896a-9041b8ec1d6d\\billiards-282415.jpg__180x180_q85_crop_subsampling-2_upscale.jpg','2016-12-21 17:48:18.068000',1),(6,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/83/48/8348387a-2122-42cc-896a-9041b8ec1d6d\\billiards-282415.jpg__1170x731_q85_crop_subsampling-2_upscale.jpg','2016-12-21 17:54:03.449000',1),(7,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/09/fc/09fca868-4484-4a24-93b9-fb674eb892fa\\pool-216416.jpg__32x32_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:24:03.453000',2),(8,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/45/58/4558d640-2d7c-405a-8063-66d13c5229fa\\pool-table-1331037.jpg__32x32_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:24:03.818000',3),(9,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/09/fc/09fca868-4484-4a24-93b9-fb674eb892fa\\pool-216416.jpg__64x64_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:24:05.146000',2),(10,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/45/58/4558d640-2d7c-405a-8063-66d13c5229fa\\pool-table-1331037.jpg__64x64_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:24:05.442000',3),(11,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/09/fc/09fca868-4484-4a24-93b9-fb674eb892fa\\pool-216416.jpg__48x48_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:24:06.692000',2),(12,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/45/58/4558d640-2d7c-405a-8063-66d13c5229fa\\pool-table-1331037.jpg__48x48_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:24:07.694000',3),(13,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/09/fc/09fca868-4484-4a24-93b9-fb674eb892fa\\pool-216416.jpg__16x16_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:24:08.540000',2),(14,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/45/58/4558d640-2d7c-405a-8063-66d13c5229fa\\pool-table-1331037.jpg__16x16_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:24:09.573000',3),(15,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/09/fc/09fca868-4484-4a24-93b9-fb674eb892fa\\pool-216416.jpg__180x180_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:24:10.197000',2),(16,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/45/58/4558d640-2d7c-405a-8063-66d13c5229fa\\pool-table-1331037.jpg__180x180_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:24:11.310000',3),(17,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/09/fc/09fca868-4484-4a24-93b9-fb674eb892fa\\pool-216416.jpg__1170x731_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:24:57.598000',2),(18,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/45/58/4558d640-2d7c-405a-8063-66d13c5229fa\\pool-table-1331037.jpg__1170x731_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:27:24.303000',3),(19,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/e4/fd/e4fd95da-52fb-45b3-a0d0-3a47dab3af38\\table-386824.jpg__32x32_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:49:04.505000',4),(20,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/e4/fd/e4fd95da-52fb-45b3-a0d0-3a47dab3af38\\table-386824.jpg__64x64_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:49:04.893000',4),(21,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/e4/fd/e4fd95da-52fb-45b3-a0d0-3a47dab3af38\\table-386824.jpg__48x48_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:49:05.207000',4),(22,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/e4/fd/e4fd95da-52fb-45b3-a0d0-3a47dab3af38\\table-386824.jpg__16x16_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:49:05.427000',4),(23,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/e4/fd/e4fd95da-52fb-45b3-a0d0-3a47dab3af38\\table-386824.jpg__180x180_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:49:05.687000',4),(24,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/e4/fd/e4fd95da-52fb-45b3-a0d0-3a47dab3af38\\table-386824.jpg__1170x731_q85_crop_subsampling-2_upscale.jpg','2016-12-21 18:50:51.362000',4),(25,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/83/48/8348387a-2122-42cc-896a-9041b8ec1d6d\\billiards-282415.jpg__1170x501_q85_crop_subsampling-2_upscale.jpg','2016-12-21 20:44:46.322000',1),(26,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/09/fc/09fca868-4484-4a24-93b9-fb674eb892fa\\pool-216416.jpg__1170x501_q85_crop_subsampling-2_upscale.jpg','2016-12-21 20:44:48.914000',2),(27,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/45/58/4558d640-2d7c-405a-8063-66d13c5229fa\\pool-table-1331037.jpg__1170x501_q85_crop_subsampling-2_upscale.jpg','2016-12-21 20:44:51.767000',3),(28,'f9bde26a1556cd667f742bd34ec7c55e','filer_public_thumbnails\\filer_public/e4/fd/e4fd95da-52fb-45b3-a0d0-3a47dab3af38\\table-386824.jpg__1170x501_q85_crop_subsampling-2_upscale.jpg','2016-12-21 20:44:52.288000',4);
/*!40000 ALTER TABLE `easy_thumbnails_thumbnail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `easy_thumbnails_thumbnaildimensions`
--

DROP TABLE IF EXISTS `easy_thumbnails_thumbnaildimensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `easy_thumbnails_thumbnaildimensions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thumbnail_id` int(11) NOT NULL,
  `width` int(10) unsigned DEFAULT NULL,
  `height` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `thumbnail_id` (`thumbnail_id`),
  CONSTRAINT `easy_thumb_thumbnail_id_314c3e84_fk_easy_thumbnails_thumbnail_id` FOREIGN KEY (`thumbnail_id`) REFERENCES `easy_thumbnails_thumbnail` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `easy_thumbnails_thumbnaildimensions`
--

LOCK TABLES `easy_thumbnails_thumbnaildimensions` WRITE;
/*!40000 ALTER TABLE `easy_thumbnails_thumbnaildimensions` DISABLE KEYS */;
/*!40000 ALTER TABLE `easy_thumbnails_thumbnaildimensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filer_clipboard`
--

DROP TABLE IF EXISTS `filer_clipboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filer_clipboard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `filer_clipboard_e8701ad4` (`user_id`),
  CONSTRAINT `filer_clipboard_user_id_2cd235df_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filer_clipboard`
--

LOCK TABLES `filer_clipboard` WRITE;
/*!40000 ALTER TABLE `filer_clipboard` DISABLE KEYS */;
INSERT INTO `filer_clipboard` VALUES (1,1);
/*!40000 ALTER TABLE `filer_clipboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filer_clipboarditem`
--

DROP TABLE IF EXISTS `filer_clipboarditem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filer_clipboarditem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clipboard_id` int(11) NOT NULL,
  `file_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `filer_clipboarditem_clipboard_id_1aea2cdc_fk_filer_clipboard_id` (`clipboard_id`),
  KEY `filer_clipboarditem_814552b9` (`file_id`),
  CONSTRAINT `filer_clipboarditem_clipboard_id_1aea2cdc_fk_filer_clipboard_id` FOREIGN KEY (`clipboard_id`) REFERENCES `filer_clipboard` (`id`),
  CONSTRAINT `filer_clipboarditem_file_id_4a5c0d4f_fk_filer_file_id` FOREIGN KEY (`file_id`) REFERENCES `filer_file` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filer_clipboarditem`
--

LOCK TABLES `filer_clipboarditem` WRITE;
/*!40000 ALTER TABLE `filer_clipboarditem` DISABLE KEYS */;
/*!40000 ALTER TABLE `filer_clipboarditem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filer_file`
--

DROP TABLE IF EXISTS `filer_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filer_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file` varchar(255) DEFAULT NULL,
  `_file_size` int(11) DEFAULT NULL,
  `sha1` varchar(40) NOT NULL,
  `has_all_mandatory_data` tinyint(1) NOT NULL,
  `original_filename` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` longtext,
  `uploaded_at` datetime(6) NOT NULL,
  `modified_at` datetime(6) NOT NULL,
  `is_public` tinyint(1) NOT NULL,
  `folder_id` int(11),
  `owner_id` int(11),
  `polymorphic_ctype_id` int(11),
  PRIMARY KEY (`id`),
  KEY `filer_file_a8a44dbb` (`folder_id`),
  KEY `filer_file_5e7b1936` (`owner_id`),
  KEY `filer_file_d3e32c49` (`polymorphic_ctype_id`),
  CONSTRAINT `filer_fi_polymorphic_ctype_id_3485cdc6_fk_django_content_type_id` FOREIGN KEY (`polymorphic_ctype_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `filer_file_folder_id_71f59785_fk_filer_folder_id` FOREIGN KEY (`folder_id`) REFERENCES `filer_folder` (`id`),
  CONSTRAINT `filer_file_owner_id_3ea33283_fk_auth_user_id` FOREIGN KEY (`owner_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filer_file`
--

LOCK TABLES `filer_file` WRITE;
/*!40000 ALTER TABLE `filer_file` DISABLE KEYS */;
INSERT INTO `filer_file` VALUES (1,'filer_public/83/48/8348387a-2122-42cc-896a-9041b8ec1d6d/billiards-282415.jpg',396129,'bd90543fcd482e61b87b8434d5e72936a1d6a85a',0,'billiards-282415.jpg','',NULL,'2016-12-21 17:48:16.142000','2016-12-21 17:48:16.142000',1,NULL,1,28),(2,'filer_public/09/fc/09fca868-4484-4a24-93b9-fb674eb892fa/pool-216416.jpg',2355946,'1af910a28737c6b6d8db8fc33f7d00b53686b56b',0,'pool-216416.jpg','',NULL,'2016-12-21 18:24:01.560000','2016-12-21 18:24:01.560000',1,NULL,1,28),(3,'filer_public/45/58/4558d640-2d7c-405a-8063-66d13c5229fa/pool-table-1331037.jpg',2689770,'8aa269a4ad39d935f9bbec96b646262a0c552cc7',0,'pool-table-1331037.jpg','',NULL,'2016-12-21 18:24:01.725000','2016-12-21 18:24:01.725000',1,NULL,1,28),(4,'filer_public/e4/fd/e4fd95da-52fb-45b3-a0d0-3a47dab3af38/table-386824.jpg',278967,'beb4a8672f1dcc4a27ee64982123b7c2c5caaee0',0,'table-386824.jpg','',NULL,'2016-12-21 18:49:03.992000','2016-12-21 18:49:03.992000',1,NULL,1,28);
/*!40000 ALTER TABLE `filer_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filer_folder`
--

DROP TABLE IF EXISTS `filer_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filer_folder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `uploaded_at` datetime(6) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `modified_at` datetime(6) NOT NULL,
  `lft` int(10) unsigned NOT NULL,
  `rght` int(10) unsigned NOT NULL,
  `tree_id` int(10) unsigned NOT NULL,
  `level` int(10) unsigned NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filer_folder_parent_id_4d901e49_uniq` (`parent_id`,`name`),
  KEY `filer_folder_caf7cc51` (`lft`),
  KEY `filer_folder_3cfbd988` (`rght`),
  KEY `filer_folder_656442a0` (`tree_id`),
  KEY `filer_folder_c9e9a848` (`level`),
  KEY `filer_folder_owner_id_3a76f3ed_fk_auth_user_id` (`owner_id`),
  CONSTRAINT `filer_folder_owner_id_3a76f3ed_fk_auth_user_id` FOREIGN KEY (`owner_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `filer_folder_parent_id_3ce3d341_fk_filer_folder_id` FOREIGN KEY (`parent_id`) REFERENCES `filer_folder` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filer_folder`
--

LOCK TABLES `filer_folder` WRITE;
/*!40000 ALTER TABLE `filer_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `filer_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filer_folderpermission`
--

DROP TABLE IF EXISTS `filer_folderpermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filer_folderpermission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` smallint(6) NOT NULL,
  `everybody` tinyint(1) NOT NULL,
  `can_edit` smallint(6) DEFAULT NULL,
  `can_read` smallint(6) DEFAULT NULL,
  `can_add_children` smallint(6) DEFAULT NULL,
  `folder_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `filer_folderpermission_folder_id_11df6568_fk_filer_folder_id` (`folder_id`),
  KEY `filer_folderpermission_group_id_7ebbde2_fk_auth_group_id` (`group_id`),
  KEY `filer_folderpermission_user_id_785f0ea5_fk_auth_user_id` (`user_id`),
  CONSTRAINT `filer_folderpermission_folder_id_11df6568_fk_filer_folder_id` FOREIGN KEY (`folder_id`) REFERENCES `filer_folder` (`id`),
  CONSTRAINT `filer_folderpermission_group_id_7ebbde2_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `filer_folderpermission_user_id_785f0ea5_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filer_folderpermission`
--

LOCK TABLES `filer_folderpermission` WRITE;
/*!40000 ALTER TABLE `filer_folderpermission` DISABLE KEYS */;
/*!40000 ALTER TABLE `filer_folderpermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filer_image`
--

DROP TABLE IF EXISTS `filer_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filer_image` (
  `file_ptr_id` int(11) NOT NULL,
  `_height` int(11) DEFAULT NULL,
  `_width` int(11) DEFAULT NULL,
  `date_taken` datetime(6) DEFAULT NULL,
  `default_alt_text` varchar(255) DEFAULT NULL,
  `default_caption` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `must_always_publish_author_credit` tinyint(1) NOT NULL,
  `must_always_publish_copyright` tinyint(1) NOT NULL,
  `subject_location` varchar(64) NOT NULL,
  PRIMARY KEY (`file_ptr_id`),
  CONSTRAINT `filer_image_file_ptr_id_2bce39a6_fk_filer_file_id` FOREIGN KEY (`file_ptr_id`) REFERENCES `filer_file` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filer_image`
--

LOCK TABLES `filer_image` WRITE;
/*!40000 ALTER TABLE `filer_image` DISABLE KEYS */;
INSERT INTO `filer_image` VALUES (1,1232,2048,'2016-12-21 17:48:15.930000',NULL,NULL,NULL,0,0,''),(2,3456,5184,'2016-12-21 18:24:01.527000',NULL,NULL,NULL,0,0,''),(3,3648,5472,'2016-12-21 18:24:01.544000',NULL,NULL,NULL,0,0,''),(4,789,1581,'2016-12-21 18:49:03.940000',NULL,NULL,NULL,0,0,'');
/*!40000 ALTER TABLE `filer_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filer_thumbnailoption`
--

DROP TABLE IF EXISTS `filer_thumbnailoption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filer_thumbnailoption` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `crop` tinyint(1) NOT NULL,
  `upscale` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filer_thumbnailoption`
--

LOCK TABLES `filer_thumbnailoption` WRITE;
/*!40000 ALTER TABLE `filer_thumbnailoption` DISABLE KEYS */;
/*!40000 ALTER TABLE `filer_thumbnailoption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus_cachekey`
--

DROP TABLE IF EXISTS `menus_cachekey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menus_cachekey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `site` int(10) unsigned NOT NULL,
  `key` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus_cachekey`
--

LOCK TABLES `menus_cachekey` WRITE;
/*!40000 ALTER TABLE `menus_cachekey` DISABLE KEYS */;
INSERT INTO `menus_cachekey` VALUES (53,'pt-br',1,'menu_cache_menu_nodes_pt-br_1_1_user');
/*!40000 ALTER TABLE `menus_cachekey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'fmsb'
--

--
-- Dumping routines for database 'fmsb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-24 13:02:43
